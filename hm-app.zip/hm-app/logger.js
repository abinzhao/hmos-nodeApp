const winston = require('winston');
const chalk = require('chalk');
require('dotenv').config();

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(info => {
      return `${info.timestamp} [${info.level.toUpperCase()}] ${info.message}`;
    })
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf(info => {
          const level = info.level;
          const message = info.message;
          
          if (level.includes('error')) {
            return chalk.red(`${info.timestamp} [${level}] ${message}`);
          } else if (level.includes('warn')) {
            return chalk.yellow(`${info.timestamp} [${level}] ${message}`);
          } else if (level.includes('info')) {
            return chalk.green(`${info.timestamp} [${level}] ${message}`);
          } else {
            return `${info.timestamp} [${level}] ${message}`;
          }
        })
      )
    }),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

// 确保日志目录存在
const fs = require('fs');
const logDir = 'logs';
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

module.exports = logger;