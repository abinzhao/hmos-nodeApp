# HarmonyOS 应用服务器 API 文档

## 项目概述

这是一个为HarmonyOS开发者社区提供的后端服务，主要功能包括：
- 用户认证与授权管理
- 代码片段分享与管理
- 应用发布与下载
- 技术讨论与交流

## 技术栈

### 后端
- Node.js (v16+)
- Express.js 框架
- MySQL 数据库
- JWT 认证

### 开发工具
- npm 包管理
- dotenv 环境变量管理
- morgan 请求日志
- chalk 控制台美化

## 服务器启动

## 开发指南

### 数据库设计

#### 用户表 (users)
- id: 主键
- username: 用户名
- password: 加密密码
- email: 邮箱
- avatar: 头像URL
- role: 角色(admin/user)
- tag: 用户标签
- created_at: 创建时间

#### 代码片段表 (snippets)
- id: 主键
- title: 标题
- description: 描述
- code: 代码内容
- language: 编程语言
- tags: 标签
- user_id: 用户ID
- created_at: 创建时间

#### 应用表 (apps)
- id: 主键
- name: 应用名称
- description: 描述
- version: 版本号
- package_path: 安装包路径
- icon_path: 图标路径
- screenshots: 截图路径
- user_id: 用户ID
- created_at: 创建时间

### 部署说明

1. 服务器要求
- Node.js v16+
- MySQL 5.7+
- 至少1GB内存

2. 生产环境配置
```bash
# 使用PM2管理进程
npm install -g pm2
pm2 start server.js --name harmonyos-server

# 设置开机启动
pm2 startup
pm2 save
```

3. 监控与日志
```bash
# 查看日志
pm2 logs harmonyos-server

# 监控状态
pm2 monit
```

1. 安装依赖
```bash
npm install
```

2. 配置环境变量
创建 `.env` 文件并配置以下变量：
```
DB_HOST=数据库主机地址
DB_USER=数据库用户名
DB_PASSWORD=数据库密码
DB_NAME=数据库名称
PORT=服务器端口(默认3000)
JWT_SECRET=JWT密钥
UPLOAD_DIR=上传文件目录(默认./uploads)
MAX_FILE_SIZE=最大文件大小(字节,默认10485760)
```

3. 启动服务器
```bash
npm start
```

## 接口文档

### 测试HTML页面

在`public/test.html`中提供了一个测试页面，可以用来测试所有API接口。

#### 分页测试示例
```html
<!DOCTYPE html>
<html>
<head>
    <title>API测试页面</title>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
</head>
<body>
    <h1>分页测试</h1>
    
    <div>
        <h2>获取分页帖子</h2>
        <input type="number" id="page" placeholder="页码" value="1">
        <input type="number" id="limit" placeholder="每页数量" value="10">
        <button onclick="getPosts()">获取帖子</button>
        <pre id="postsResult"></pre>
    </div>
    
    <script>
        function getPosts() {
            const page = document.getElementById('page').value;
            const limit = document.getElementById('limit').value;
            
            axios.get(`/api/posts?page=${page}&limit=${limit}`)
                .then(response => {
                    document.getElementById('postsResult').innerText = 
                        JSON.stringify(response.data, null, 2);
                })
                .catch(error => {
                    document.getElementById('postsResult').innerText = 
                        '错误: ' + error.response.data.message;
                });
        }
    </script>
</body>
</html>
```

#### 用户内容测试示例
```html
<div>
    <h2>获取用户帖子</h2>
    <input type="number" id="userId" placeholder="用户ID" value="1">
    <input type="number" id="userPage" placeholder="页码" value="1">
    <input type="number" id="userLimit" placeholder="每页数量" value="10">
    <button onclick="getUserPosts()">获取用户帖子</button>
    <pre id="userPostsResult"></pre>
</div>

<script>
    function getUserPosts() {
        const userId = document.getElementById('userId').value;
        const page = document.getElementById('userPage').value;
        const limit = document.getElementById('userLimit').value;
        
        axios.get(`/api/posts/user/${userId}?page=${page}&limit=${limit}`)
            .then(response => {
                document.getElementById('userPostsResult').innerText = 
                    JSON.stringify(response.data, null, 2);
            })
            .catch(error => {
                document.getElementById('userPostsResult').innerText = 
                    '错误: ' + error.response.data.message;
            });
    }
</script>
```

### 用户接口

#### 获取所有用户(分页)
- **URL**: `/api/users`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "username": "用户名",
      "email": "用户邮箱",
      "avatar": "头像URL",
      "role": "用户角色",
      "created_at": "创建时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

#### 获取用户帖子(分页)
- **URL**: `/api/users/:userId/posts`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "title": "帖子标题",
      "content": "帖子内容",
      "author_id": 1,
      "created_at": "创建时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

#### 获取用户代码片段(分页)
- **URL**: `/api/users/:userId/snippets`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "title": "代码片段标题",
      "code": "代码内容",
      "language": "编程语言",
      "user_id": 1,
      "created_at": "创建时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

#### 获取用户应用(分页)
- **URL**: `/api/users/:userId/apps`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "name": "应用名称",
      "packageName": "应用包名",
      "icon": "应用icon",
      "version": "应用版本",
      "description": "应用描述",
      "tags": "应用标签",
      "screenshots": ["截图1URL", "截图2URL"],
      "author_id": 1,
      "downloads": 0,
      "created_at": "上传时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

### 用户接口

#### 获取所有用户(分页)
- **URL**: `/api/users`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "username": "用户名",
      "email": "邮箱",
      "role": "用户角色",
      "avatar": "用户头像URL",
      "tag": "用户标签",
      "openId": "用户OpenID",
      "createdAt": "创建时间"
    }
  ],
  "total": 100,
  "page": 1,
  "limit": 10
}
```

#### 获取用户详情
- **URL**: `/api/users/:userId`
- **Method**: `GET`
- **Success Response":
```json
{
  "id": 1,
  "username": "用户名",
  "email": "邮箱",
  "role": "用户角色",
  "avatar": "用户头像URL",
  "tag": "用户标签",
  "openId": "用户OpenID",
  "createdAt": "创建时间",
  "postCount": 10,
  "snippetCount": 5,
  "appCount": 3
}
```

### 认证接口

#### 用户注册
- **URL**: `/api/auth/register`
- **Method**: `POST`
- **Request Body**:
```json
{
  "username": "用户名",
  "password": "密码",
  "email": "邮箱",
  "avatar": "用户头像URL",
  "role": "用户角色",
  "tag": "用户标签"
}
```
- **Success Response**:
```json
{
  "message": "用户注册成功",
  "userId": 1,
  "openId": "用户OpenID"
}
```

#### 用户登录
- **URL**: `/api/auth/login`
- **Method**: `POST`
- **Request Body**:
```json
{
  "username": "用户名",
  "password": "密码"
}
```
- **Success Response**:
```json
{
  "message": "登录成功",
  "token": "JWT令牌",
  "user": {
    "id": 1,
    "username": "用户名",
    "email": "邮箱",
    "role": "用户角色",
    "avatar": "用户头像URL",
    "tag": "用户标签",
    "openId": "用户OpenID",
    "createdAt": "创建时间"
  }
}
```

### 上传接口

#### 图片上传
- **URL**: `/api/uploads/images`
- **Method**: `POST`
- **Headers**: `Content-Type: multipart/form-data`
- **Form Data**: `image: (文件)`
- **Success Response**:
```json
{
  "message": "图片上传成功",
  "path": "文件路径",
  "url": "访问URL"
}
```

#### 应用安装包上传
- **URL**: `/api/uploads/apps`
- **Method**: `POST`
- **Headers**: `Content-Type: multipart/form-data`
- **Form Data**: `app: (文件)`
- **Success Response**:
```json
{
  "message": "应用安装包上传成功",
  "path": "文件路径",
  "url": "访问URL"
}
```

### 帖子接口

#### 创建帖子
- **URL**: `/api/posts`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
```json
{
  "title": "标题",
  "description": "说明描述",
  "content": "内容",
  "tags": "标签",
  "author_id": 1
}
```
- **Success Response**:
```json
{
  "message": "帖子创建成功",
  "postId": 1
}
```

#### 获取所有帖子
- **URL**: `/api/posts`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "title": "标题",
      "description": "说明描述",
      "content": "内容",
      "tags": "标签",
      "author_id": 1,
      "created_at": "创建时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 100,
  "page": 1,
  "limit": 10
}
```

#### 获取用户帖子
- **URL**: `/api/posts/user/:userId`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "title": "标题",
      "description": "说明描述",
      "content": "内容",
      "tags": "标签",
      "author_id": 1,
      "created_at": "创建时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

### 代码片段接口

#### 创建代码片段
- **URL**: `/api/snippets`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
```json
{
  "title": "标题",
  "description": "描述",
  "code": "代码内容",
  "language": "编程语言",
  "tags": "标签",
  "user_id": 1
}
```
- **Success Response**:
```json
{
  "message": "代码片段创建成功",
  "snippetId": 1
}
```

#### 获取所有代码片段
- **URL**: `/api/snippets`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "title": "标题",
      "description": "描述",
      "code": "代码内容",
      "language": "编程语言",
      "tags": "标签",
      "user_id": 1,
      "created_at": "创建时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 100,
  "page": 1,
  "limit": 10
}
```

#### 获取用户代码片段
- **URL**: `/api/snippets/user/:userId`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "title": "标题",
      "description": "描述",
      "code": "代码内容",
      "language": "编程语言",
      "tags": "标签",
      "user_id": 1,
      "created_at": "创建时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

### 应用接口

#### 创建应用
- **URL**: `/api/apps`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
```json
{
  "name": "应用名称",
  "packageName": "应用包名",
  "icon": "应用icon",
  "version": "应用版本",
  "description": "应用描述",
  "tags": "应用标签",
  "screenshots": ["截图1URL", "截图2URL"],
  "author_id": 1
}
```
- **Success Response**:
```json
{
  "message": "应用创建成功",
  "appId": 1
}
```

#### 获取所有应用
- **URL**: `/api/apps`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "name": "应用名称",
      "packageName": "应用包名",
      "icon": "应用icon",
      "version": "应用版本",
      "description": "应用描述",
      "tags": "应用标签",
      "screenshots": ["截图1URL", "截图2URL"],
      "author_id": 1,
      "downloads": 0,
      "created_at": "上传时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 100,
  "page": 1,
  "limit": 10
}
```

#### 获取用户应用
- **URL**: `/api/apps/user/:userId`
- **Method**: `GET`
- **Query Params**:
```
page=页码(从1开始)
limit=每页数量(默认10)
```
- **Success Response**:
```json
{
  "data": [
    {
      "id": 1,
      "name": "应用名称",
      "packageName": "应用包名",
      "icon": "应用icon",
      "version": "应用版本",
      "description": "应用描述",
      "tags": "应用标签",
      "screenshots": ["截图1URL", "截图2URL"],
      "author_id": 1,
      "downloads": 0,
      "created_at": "上传时间",
      "updated_at": "更新时间"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 10
}
```

### 系统通知接口

#### 获取所有通知
- **URL**: `/api/notifications`
- **Method**: `GET`
- **Success Response**:
```json
[
  {
    "id": 1,
    "title": "标题",
    "description": "说明描述",
    "content": "内容",
    "created_at": "发布时间"
  }
]
```

### 留言接口

#### 创建留言
- **URL**: `/api/comments`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer <token>`
- **Request Body**:
```json
{
  "type": "帖子/代码片段/应用",
  "targetId": 1,
  "userId": 1,
  "username": "留言者名称",
  "content": "留言内容"
}
```
- **Success Response**:
```json
{
  "message": "留言创建成功",
  "commentId": 1
}
```

#### 获取留言
- **URL**: `/api/comments`
- **Method**: `GET`
- **Query Params**:
```
type=帖子/代码片段/应用
targetId=1
```
- **Success Response**:
```json
[
  {
    "id": 1,
    "type": "帖子/代码片段/应用",
    "targetId": 1,
    "userId": 1,
    "username": "留言者名称",
    "content": "留言内容",
    "created_at": "留言时间"
  }
]
```

## 错误码

| 状态码 | 描述 |
|--------|------|
| 400 | 请求参数错误 |
| 401 | 未授权/认证失败 |
| 403 | 禁止访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |