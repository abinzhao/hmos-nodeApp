const net = require('net');
const logger = require('./logger');
const { exec } = require('child_process');

class TCPServer {
  constructor(port = 8081) {
    this.port = port;
    this.server = net.createServer();
    this.clients = new Map();
    
    this.server.on('connection', (socket) => this.handleConnection(socket));
    this.server.on('error', (err) => this.handleError(err));
  }
  
  handleConnection(socket) {
    const clientId = `${socket.remoteAddress}:${socket.remotePort}`;
    this.clients.set(clientId, socket);
    logger.info(`设备连接: ${clientId}`);
    
    socket.on('data', (data) => this.handleData(clientId, data));
    socket.on('close', () => this.handleClose(clientId));
    socket.on('error', (err) => this.handleClientError(clientId, err));
  }
  
  handleData(clientId, data) {
    const command = data.toString().trim();
    logger.info(`收到命令: ${command} from ${clientId}`);
    
    exec(command, (error, stdout, stderr) => {
      const socket = this.clients.get(clientId);
      if (!socket || socket.destroyed) return;
      
      const response = error 
        ? `命令执行失败: ${error.message}` 
        : stdout || stderr;
      
      socket.write(response);
    });
  }
  
  handleClose(clientId) {
    this.clients.delete(clientId);
    logger.info(`设备断开: ${clientId}`);
  }
  
  handleClientError(clientId, err) {
    logger.error(`设备错误: ${clientId} - ${err.message}`);
    this.clients.delete(clientId);
  }
  
  handleError(err) {
    logger.error(`服务器错误: ${err.message}`);
  }
  
  start() {
    this.server.listen(this.port, () => {
      logger.info(`TCP服务器启动，监听端口: ${this.port}`);
    });
  }
}

module.exports = TCPServer;