const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接配置
const config = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || ''
};

// 表结构定义
const tables = {
  users: `CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE,
    avatar VARCHAR(255),
    role ENUM('user', 'admin') DEFAULT 'user',
    tag VARCHAR(100),
    openId VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )`,
  
  posts: `CREATE TABLE IF NOT EXISTS posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    content TEXT NOT NULL,
    tags VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  
  snippets: `CREATE TABLE IF NOT EXISTS snippets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    code TEXT NOT NULL,
    language VARCHAR(50) NOT NULL,
    tags VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  
  apps: `CREATE TABLE IF NOT EXISTS apps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    version VARCHAR(20) NOT NULL,
    package_path VARCHAR(255) NOT NULL,
    icon_path VARCHAR(255),
    screenshots TEXT,
    downloads INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  
  comments: `CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    parent_type ENUM('post', 'snippet', 'app') NOT NULL,
    parent_id INT NOT NULL,
    comment_type VARCHAR(50),
    commenter_name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  
  notifications: `CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    publish_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`
};

async function initDatabase() {
  try {
    // 创建数据库连接
    const connection = await mysql.createConnection(config);
    
    // 检查数据库是否存在
    const [dbs] = await connection.query('SHOW DATABASES LIKE ?', [process.env.DB_NAME || 'harmonyosSQL']);
    
    if (dbs.length === 0) {
      // 数据库不存在则创建
      await connection.query(`CREATE DATABASE ${process.env.DB_NAME || 'harmonyosSQL'}`);
      console.log(chalk.green(`✓ 数据库 ${process.env.DB_NAME || 'harmonyosSQL'} 创建完成`));
    } else {
      console.log(chalk.green(`✓ 数据库 ${process.env.DB_NAME || 'harmonyosSQL'} 已存在`));
    }
    
    // 切换到目标数据库
    await connection.query(`USE ${process.env.DB_NAME || 'harmonyosSQL'}`);
    
    // 创建所有表
    for (const [tableName, sql] of Object.entries(tables)) {
      await connection.query(sql);
      console.log(chalk.green(`✓ 表 ${tableName} 检查/创建完成`));
    }
    
    await connection.end();
    console.log(chalk.green.bold('\n✅ 数据库初始化完成！\n'));
  } catch (error) {
    console.error(chalk.red('❌ 数据库初始化失败:'), error);
    process.exit(1);
  }
}

// 导出初始化函数
module.exports = initDatabase;