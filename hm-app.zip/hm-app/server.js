const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const morgan = require('morgan');
const chalk = require('chalk');
const path = require('path');
const initDatabase = require('./db-init');
const TCPServer = require('./tcp-server');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
initDatabase()
// 路由
const authRouter = require('./routes/auth');
const uploadRouter = require('./routes/uploads');
const postRouter = require('./routes/posts');
const snippetRouter = require('./routes/snippets');
const appRouter = require('./routes/apps');
const notificationRouter = require('./routes/notifications');
const commentRouter = require('./routes/comments');

app.use('/api/auth', authRouter);
app.use('/api/uploads', uploadRouter);
app.use('/api/posts', postRouter);
app.use('/api/snippets', snippetRouter);
app.use('/api/apps', appRouter);
app.use('/api/notifications', notificationRouter);
app.use('/api/comments', commentRouter);

// 启动服务器
function startServer(port) {
  app.listen(port, () => {
    console.log(chalk.green.bold('\n🚀 HarmonyOS 应用服务器已启动'));
    console.log(chalk.blue(`\n访问地址: http://localhost:${port}`));
    console.log(chalk.blue(`环境: ${process.env.NODE_ENV || 'development'}`));
    console.log(chalk.blue(`数据库: ${process.env.DB_NAME || 'harmonyosSQL'}`));
    console.log(chalk.blue(`日志级别: ${process.env.LOG_LEVEL || 'info'}\n`));
  }).on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(chalk.yellow(`端口 ${port} 被占用，尝试端口 ${port + 1}`));
      startServer(Number(port) + 1);
    } else {
      console.error(chalk.red('❌ 服务器启动失败:'), err);
    }
  });
}

// 启动TCP服务器
const tcpServer = new TCPServer();
tcpServer.start();

startServer(port);

module.exports = app;