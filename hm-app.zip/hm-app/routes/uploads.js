const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const chalk = require('chalk');
require('dotenv').config();

// 确保上传目录存在
const uploadDir = process.env.UPLOAD_DIR || './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// 文件存储配置
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// 文件过滤器
const fileFilter = (req, file, cb) => {
  const filetypes = /jpeg|jpg|png|gif|apk|ipa/;
  const mimetype = filetypes.test(file.mimetype);
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  
  if (mimetype && extname) {
    return cb(null, true);
  }
  cb(new Error('只允许上传图片或应用安装包文件'));
};

// 上传中间件
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10485760 // 默认10MB
  }
});

// 图片上传
router.post('/images', upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: '请上传有效的图片文件' });
  }
  
  const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
  
  res.status(201).json({
    message: '图片上传成功',
    path: req.file.path,
    url: fileUrl
  });
  
  const filePath = path.join(uploadDir, req.file.filename);
  const fileUrl_load = `/uploads/${req.file.filename}`;
  
  res.json({
    message: '图片上传成功',
    path: filePath,
    url: fileUrl_load
  });
  
  console.log(chalk.green(`✓ 图片上传成功: ${req.file.filename}`));
});

// 应用安装包上传
router.post('/apps', upload.single('app'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: '请上传有效的应用安装包' });
  }
  
  const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
  
  res.status(201).json({
    message: '应用安装包上传成功',
    path: req.file.path,
    url: fileUrl
  });
  
  const filePath = path.join(uploadDir, req.file.filename);
  const fileUrl_load = `/uploads/${req.file.filename}`;
  
  res.json({
    message: '应用安装包上传成功',
    path: filePath,
    url: fileUrl_load
  });
  
  console.log(chalk.green(`✓ 应用安装包上传成功: ${req.file.filename}`));
});

module.exports = router;