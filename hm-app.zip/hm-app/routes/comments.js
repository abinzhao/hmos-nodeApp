const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 创建留言
router.post('/', async (req, res) => {
  try {
    const { user_id, content, parent_type, parent_id, comment_type, commenter_name } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO comments (user_id, content, parent_type, parent_id, comment_type, commenter_name) VALUES (?, ?, ?, ?, ?, ?)',
      [user_id, content, parent_type, parent_id, comment_type, commenter_name]
    );
    
    res.status(201).json({ 
      message: '留言创建成功',
      commentId: result.insertId 
    });
    
    console.log(chalk.green(`✓ 新留言创建: ${content.substring(0, 20)}...`));
  } catch (error) {
    console.error(chalk.red('❌ 留言创建错误:'), error);
    res.status(500).json({ error: '留言创建失败' });
  }
});

// 获取父级所有留言
router.get('/parent/:parentType/:parentId', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM comments WHERE parent_type = ? AND parent_id = ?',
      [req.params.parentType, req.params.parentId]
    );
    res.json(rows);
  } catch (error) {
    console.error(chalk.red('❌ 获取留言列表错误:'), error);
    res.status(500).json({ error: '获取留言列表失败' });
  }
});

// 获取用户所有留言
router.get('/user/:userId', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM comments WHERE user_id = ?', [req.params.userId]);
    res.json(rows);
  } catch (error) {
    console.error(chalk.red('❌ 获取用户留言错误:'), error);
    res.status(500).json({ error: '获取用户留言失败' });
  }
});

// 获取单个留言
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM comments WHERE id = ?', [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: '留言不存在' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error(chalk.red('❌ 获取留言错误:'), error);
    res.status(500).json({ error: '获取留言失败' });
  }
});

// 删除留言
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM comments WHERE id = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '留言不存在' });
    }
    
    res.json({ message: '留言删除成功' });
    console.log(chalk.green(`✓ 留言删除: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 留言删除错误:'), error);
    res.status(500).json({ error: '留言删除失败' });
  }
});

module.exports = router;