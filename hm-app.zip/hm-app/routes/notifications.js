const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 创建通知
router.post('/', async (req, res) => {
  try {
    const { user_id, title, message } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)',
      [user_id, title, message]
    );
    
    res.status(201).json({ 
      message: '通知创建成功',
      notificationId: result.insertId 
    });
    
    console.log(chalk.green(`✓ 新通知创建: ${title}`));
  } catch (error) {
    console.error(chalk.red('❌ 通知创建错误:'), error);
    res.status(500).json({ error: '通知创建失败' });
  }
});

// 获取用户所有通知
router.get('/user/:userId', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM notifications WHERE user_id = ?', [req.params.userId]);
    res.json(rows);
  } catch (error) {
    console.error(chalk.red('❌ 获取通知列表错误:'), error);
    res.status(500).json({ error: '获取通知列表失败' });
  }
});
// 获取所有通知
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;

    const [rows] = await pool.query('SELECT * FROM notifications LIMIT? OFFSET?', [limit, offset]);
    const [total] = await pool.query('SELECT COUNT(*) as count FROM notifications');
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  }
  catch (error) {
    console.error(chalk.red('❌ 获取通知列表错误:'), error);
    res.status(500).json({ error: '获取通知列表失败' });
  }
})

// 获取单个通知
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM notifications WHERE id = ?', [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: '通知不存在' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error(chalk.red('❌ 获取通知错误:'), error);
    res.status(500).json({ error: '获取通知失败' });
  }
});

// 标记通知为已读
router.put('/:id/read', async (req, res) => {
  try {
    const [result] = await pool.query(
      'UPDATE notifications SET is_read = true WHERE id = ?',
      [req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '通知不存在' });
    }
    
    res.json({ message: '通知已标记为已读' });
    console.log(chalk.green(`✓ 通知标记为已读: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 标记通知错误:'), error);
    res.status(500).json({ error: '标记通知失败' });
  }
});

// 删除通知
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM notifications WHERE id = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '通知不存在' });
    }
    
    res.json({ message: '通知删除成功' });
    console.log(chalk.green(`✓ 通知删除: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 通知删除错误:'), error);
    res.status(500).json({ error: '通知删除失败' });
  }
});

module.exports = router;