const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 创建应用
router.post('/', async (req, res) => {
  try {
    const { name, description, version, package_path, icon_path, screenshots, user_id } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO apps (name, description, version, package_path, icon_path, screenshots, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name, description, version, package_path, icon_path, screenshots, user_id]
    );
    
    res.status(201).json({ 
      message: '应用创建成功',
      appId: result.insertId 
    });
    
    console.log(chalk.green(`✓ 新应用创建: ${name}`));
  } catch (error) {
    console.error(chalk.red('❌ 应用创建错误:'), error);
    res.status(500).json({ error: '应用创建失败' });
  }
});

// 获取所有应用(分页)
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    const [rows] = await pool.query('SELECT * FROM apps LIMIT ? OFFSET ?', [limit, offset]);
    const [total] = await pool.query('SELECT COUNT(*) as count FROM apps');
    
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  } catch (error) {
    console.error(chalk.red('❌ 获取应用列表错误:'), error);
    res.status(500).json({ error: '获取应用列表失败' });
  }
});

// 获取用户应用(分页)
router.get('/user/:userId', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    const [rows] = await pool.query(
      'SELECT * FROM apps WHERE user_id = ? LIMIT ? OFFSET ?', 
      [req.params.userId, limit, offset]
    );
    const [total] = await pool.query(
      'SELECT COUNT(*) as count FROM apps WHERE user_id = ?', 
      [req.params.userId]
    );
    
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  } catch (error) {
    console.error(chalk.red('❌ 获取用户应用错误:'), error);
    res.status(500).json({ error: '获取用户应用失败' });
  }
});

// 获取单个应用
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM apps WHERE id = ?', [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: '应用不存在' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error(chalk.red('❌ 获取应用错误:'), error);
    res.status(500).json({ error: '获取应用失败' });
  }
});

// 更新应用
router.put('/:id', async (req, res) => {
  try {
    const { name, description, version } = req.body;
    
    const [result] = await pool.query(
      'UPDATE apps SET name = ?, description = ?, version = ? WHERE id = ?',
      [name, description, version, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '应用不存在' });
    }
    
    res.json({ message: '应用更新成功' });
    console.log(chalk.green(`✓ 应用更新: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 应用更新错误:'), error);
    res.status(500).json({ error: '应用更新失败' });
  }
});

// 删除应用
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM apps WHERE id = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '应用不存在' });
    }
    
    res.json({ message: '应用删除成功' });
    console.log(chalk.green(`✓ 应用删除: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 应用删除错误:'), error);
    res.status(500).json({ error: '应用删除失败' });
  }
});

module.exports = router;