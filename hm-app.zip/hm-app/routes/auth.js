const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 用户注册
router.post('/register', async (req, res) => {
  try {
    const { username, password, email, avatar, role, tag } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const [result] = await pool.query(
      'INSERT INTO users (username, password, email, avatar, role, tag) VALUES (?, ?, ?, ?, ?, ?)',
      [username, hashedPassword, email, avatar, role, tag]
    );
    
    res.status(201).json({ 
      message: '用户注册成功',
      userId: result.insertId,
      openId: result.insertId.toString()
    });
    
    console.log(chalk.green(`✓ 新用户注册: ${username}`));
  } catch (error) {
    console.error(chalk.red('❌ 注册错误:'), error);
    res.status(500).json({ error: '注册失败' });
  }
});

// 用户登录
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
    
    if (rows.length === 0) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    
    const user = rows[0];
    const passwordMatch = await bcrypt.compare(password, user.password);
    
    if (!passwordMatch) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }
    
    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({ 
      message: '登录成功',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        tag: user.tag,
        openId: user.id.toString()
      }
    });
    
    console.log(chalk.green(`✓ 用户登录: ${username}`));
  } catch (error) {
    console.error(chalk.red('❌ 登录错误:'), error);
    res.status(500).json({ error: '登录失败' });
  }
});

// 更新用户权限 (管理员)
router.put('/:id/role', async (req, res) => {
  try {
    // 验证管理员权限
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: '无权执行此操作' });
    }
    
    const { role } = req.body;
    await pool.query('UPDATE users SET role = ? WHERE id = ?', [role, req.params.id]);
    
    res.json({ message: '用户权限更新成功' });
    console.log(chalk.green(`✓ 用户权限更新: ID ${req.params.id} -> ${role}`));
  } catch (error) {
    console.error(chalk.red('❌ 权限更新错误:'), error);
    res.status(500).json({ error: '权限更新失败' });
  }
});

module.exports = router;