const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 创建帖子
router.post('/', async (req, res) => {
  try {
    const { title, description, content, tags, author_id } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO posts (title, description, content, tags, author_id) VALUES (?, ?, ?, ?, ?)',
      [title, description, content, tags, author_id]
    );
    
    res.status(201).json({ 
      message: '帖子创建成功',
      postId: result.insertId
    });
    
    console.log(chalk.green(`✓ 新帖子创建: ${title}`));
  } catch (error) {
    console.error(chalk.red('❌ 帖子创建错误:'), error);
    res.status(500).json({ error: '帖子创建失败' });
  }
});

// 获取所有帖子(分页)
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    const [rows] = await pool.query('SELECT * FROM posts LIMIT ? OFFSET ?', [limit, offset]);
    const [total] = await pool.query('SELECT COUNT(*) as count FROM posts');
    
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  } catch (error) {
    console.error(chalk.red('❌ 获取帖子列表错误:'), error);
    res.status(500).json({ error: '获取帖子列表失败' });
  }
});

// 获取用户帖子(分页)
router.get('/user/:userId', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    const [rows] = await pool.query(
      'SELECT * FROM posts WHERE author_id = ? LIMIT ? OFFSET ?', 
      [req.params.userId, limit, offset]
    );
    const [total] = await pool.query(
      'SELECT COUNT(*) as count FROM posts WHERE author_id = ?', 
      [req.params.userId]
    );
    
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  } catch (error) {
    console.error(chalk.red('❌ 获取用户帖子错误:'), error);
    res.status(500).json({ error: '获取用户帖子失败' });
  }
});

// 获取单个帖子
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM posts WHERE id = ?', [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: '帖子不存在' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error(chalk.red('❌ 获取帖子错误:'), error);
    res.status(500).json({ error: '获取帖子失败' });
  }
});

// 更新帖子
router.put('/:id', async (req, res) => {
  try {
    const { title, content } = req.body;
    
    const [result] = await pool.query(
      'UPDATE posts SET title = ?, content = ? WHERE id = ?',
      [title, content, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '帖子不存在' });
    }
    
    res.json({ message: '帖子更新成功' });
    console.log(chalk.green(`✓ 帖子更新: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 帖子更新错误:'), error);
    res.status(500).json({ error: '帖子更新失败' });
  }
});

// 删除帖子
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM posts WHERE id = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '帖子不存在' });
    }
    
    res.json({ message: '帖子删除成功' });
    console.log(chalk.green(`✓ 帖子删除: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 帖子删除错误:'), error);
    res.status(500).json({ error: '帖子删除失败' });
  }
});

module.exports = router;