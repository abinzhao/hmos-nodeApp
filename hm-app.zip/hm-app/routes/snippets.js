const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

// 数据库连接池
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'harmonyosSQL',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 创建代码片段
router.post('/', async (req, res) => {
  try {
    const { title, description, code, language, tags, user_id } = req.body;
    
    const [result] = await pool.query(
      'INSERT INTO snippets (title, description, code, language, tags, user_id) VALUES (?, ?, ?, ?, ?, ?)',
      [title, description, code, language, tags, user_id]
    );
    
    res.status(201).json({ 
      message: '代码片段创建成功',
      snippetId: result.insertId 
    });
    
    console.log(chalk.green(`✓ 新代码片段创建: ${title}`));
  } catch (error) {
    console.error(chalk.red('❌ 代码片段创建错误:'), error);
    res.status(500).json({ error: '代码片段创建失败' });
  }
});

// 获取所有代码片段(分页)
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    const [rows] = await pool.query('SELECT * FROM snippets LIMIT ? OFFSET ?', [limit, offset]);
    const [total] = await pool.query('SELECT COUNT(*) as count FROM snippets');
    
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  } catch (error) {
    console.error(chalk.red('❌ 获取代码片段列表错误:'), error);
    res.status(500).json({ error: '获取代码片段列表失败' });
  }
});

// 获取用户代码片段(分页)
router.get('/user/:userId', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const offset = (page - 1) * limit;
    
    const [rows] = await pool.query(
      'SELECT * FROM snippets WHERE user_id = ? LIMIT ? OFFSET ?', 
      [req.params.userId, limit, offset]
    );
    const [total] = await pool.query(
      'SELECT COUNT(*) as count FROM snippets WHERE user_id = ?', 
      [req.params.userId]
    );
    
    res.json({
      data: rows,
      total: total[0].count,
      page,
      limit
    });
  } catch (error) {
    console.error(chalk.red('❌ 获取用户代码片段错误:'), error);
    res.status(500).json({ error: '获取用户代码片段失败' });
  }
});

// 获取单个代码片段
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM snippets WHERE id = ?', [req.params.id]);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: '代码片段不存在' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error(chalk.red('❌ 获取代码片段错误:'), error);
    res.status(500).json({ error: '获取代码片段失败' });
  }
});

// 更新代码片段
router.put('/:id', async (req, res) => {
  try {
    const { title, description, code, language } = req.body;
    
    const [result] = await pool.query(
      'UPDATE snippets SET title = ?, description = ?, code = ?, language = ? WHERE id = ?',
      [title, description, code, language, req.params.id]
    );
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '代码片段不存在' });
    }
    
    res.json({ message: '代码片段更新成功' });
    console.log(chalk.green(`✓ 代码片段更新: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 代码片段更新错误:'), error);
    res.status(500).json({ error: '代码片段更新失败' });
  }
});

// 删除代码片段
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM snippets WHERE id = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '代码片段不存在' });
    }
    
    res.json({ message: '代码片段删除成功' });
    console.log(chalk.green(`✓ 代码片段删除: ID ${req.params.id}`));
  } catch (error) {
    console.error(chalk.red('❌ 代码片段删除错误:'), error);
    res.status(500).json({ error: '代码片段删除失败' });
  }
});

module.exports = router;