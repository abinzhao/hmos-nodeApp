const mysql = require('mysql2/promise');
const chalk = require('chalk');
require('dotenv').config();

class DBUtils {
  constructor() {
    this.pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'harmonyosSQL',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
  }

  async query(sql, params = []) {
    try {
      const [rows] = await this.pool.query(sql, params);
      return rows;
    } catch (error) {
      console.error(chalk.red('❌ 数据库查询错误:'), error);
      throw error;
    }
  }

  async execute(sql, params = []) {
    try {
      const [result] = await this.pool.execute(sql, params);
      return result;
    } catch (error) {
      console.error(chalk.red('❌ 数据库执行错误:'), error);
      throw error;
    }
  }

  async beginTransaction() {
    const conn = await this.pool.getConnection();
    await conn.beginTransaction();
    return conn;
  }

  async commit(conn) {
    await conn.commit();
    conn.release();
  }

  async rollback(conn) {
    await conn.rollback();
    conn.release();
  }

  async close() {
    await this.pool.end();
  }
}

module.exports = new DBUtils();