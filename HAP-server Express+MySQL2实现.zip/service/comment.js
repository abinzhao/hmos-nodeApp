/**
 * 留言服务模块
 */
const logger = require('../utils/logger');

/**
 * 留言服务类
 */
class CommentService {
  /**
   * 构造函数
   * @param {mysql.Pool} pool - MySQL连接池
   */
  constructor(pool) {
    this.pool = pool;
  }

  /**
   * 创建新留言
   * @param {Object} commentData - 留言数据
   * @returns {Promise<Object>} 创建的留言对象
   */
  async createComment(commentData) {
    const { content_id, software_id, user_id, content } = commentData;

    // 确保至少关联一个内容或软件
    if (!content_id && !software_id) {
      throw new Error('留言必须关联到内容或软件');
    }

    try {
      // 插入留言数据
      const [result] = await this.pool.query(
        `INSERT INTO comments (content_id, software_id, user_id, content) 
         VALUES (?, ?, ?, ?)`,
        [content_id || null, software_id || null, user_id, content]
      );

      // 获取创建的留言
      const [comments] = await this.pool.query(
        'SELECT * FROM comments WHERE id = ?',
        [result.insertId]
      );

      logger.info(`留言创建成功: ID ${result.insertId}`);
      return comments[0];
    } catch (error) {
      logger.error(`创建留言失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取内容的留言
   * @param {number} contentId - 内容ID
   * @returns {Promise<Array>} 留言列表
   */
  async getContentComments(contentId) {
    try {
      const [comments] = await this.pool.query(
        `SELECT c.*, u.username 
         FROM comments c 
         JOIN users u ON c.user_id = u.id 
         WHERE c.content_id = ? 
         ORDER BY c.created_at DESC`,
        [contentId]
      );
      
      logger.info(`获取内容ID ${contentId} 的留言: 共${comments.length}条记录`);
      return comments;
    } catch (error) {
      logger.error(`获取内容留言失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取软件的留言
   * @param {number} softwareId - 软件ID
   * @returns {Promise<Array>} 留言列表
   */
  async getSoftwareComments(softwareId) {
    try {
      const [comments] = await this.pool.query(
        `SELECT c.*, u.username 
         FROM comments c 
         JOIN users u ON c.user_id = u.id 
         WHERE c.software_id = ? 
         ORDER BY c.created_at DESC`,
        [softwareId]
      );
      
      logger.info(`获取软件ID ${softwareId} 的留言: 共${comments.length}条记录`);
      return comments;
    } catch (error) {
      logger.error(`获取软件留言失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取用户的留言
   * @param {number} userId - 用户ID
   * @returns {Promise<Array>} 留言列表
   */
  async getUserComments(userId) {
    try {
      const [comments] = await this.pool.query(
        'SELECT * FROM comments WHERE user_id = ? ORDER BY created_at DESC',
        [userId]
      );
      
      logger.info(`获取用户ID ${userId} 的留言: 共${comments.length}条记录`);
      return comments;
    } catch (error) {
      logger.error(`获取用户留言失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 更新留言
   * @param {number} commentId - 留言ID
   * @param {string} content - 更新的留言内容
   * @returns {Promise<Object>} 更新后的留言对象
   */
  async updateComment(commentId, content) {
    try {
      // 检查留言是否存在
      const [comments] = await this.pool.query(
        'SELECT * FROM comments WHERE id = ?',
        [commentId]
      );

      if (comments.length === 0) {
        throw new Error('留言不存在');
      }

      // 更新留言内容
      await this.pool.query(
        'UPDATE comments SET content = ? WHERE id = ?',
        [content, commentId]
      );

      // 获取更新后的留言
      const [updatedComments] = await this.pool.query(
        'SELECT * FROM comments WHERE id = ?',
        [commentId]
      );

      logger.info(`留言更新成功: ID ${commentId}`);
      return updatedComments[0];
    } catch (error) {
      logger.error(`更新留言失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 删除留言
   * @param {number} commentId - 留言ID
   * @returns {Promise<boolean>} 是否成功删除
   */
  async deleteComment(commentId) {
    try {
      // 检查留言是否存在
      const [comments] = await this.pool.query(
        'SELECT id FROM comments WHERE id = ?',
        [commentId]
      );

      if (comments.length === 0) {
        throw new Error('留言不存在');
      }

      // 删除留言
      await this.pool.query('DELETE FROM comments WHERE id = ?', [commentId]);

      logger.info(`留言删除成功: ID ${commentId}`);
      return true;
    } catch (error) {
      logger.error(`删除留言失败: ${error.message}`);
      throw error;
    }
  }
}

module.exports = CommentService;
