/**
 * 系统通知服务模块
 */
const logger = require('../utils/logger');

/**
 * 系统通知服务类
 */
class NotificationService {
  /**
   * 构造函数
   * @param {mysql.Pool} pool - MySQL连接池
   */
  constructor(pool) {
    this.pool = pool;
  }

  /**
   * 创建新通知
   * @param {Object} notificationData - 通知数据
   * @returns {Promise<Object>} 创建的通知对象
   */
  async createNotification(notificationData) {
    const { title, content, level, user_id } = notificationData;

    try {
      // 插入通知数据
      const [result] = await this.pool.query(
        `INSERT INTO notifications (title, content, level, user_id) 
         VALUES (?, ?, ?, ?)`,
        [title, content, level || 'medium', user_id]
      );

      // 获取创建的通知
      const [notifications] = await this.pool.query(
        'SELECT * FROM notifications WHERE id = ?',
        [result.insertId]
      );

      logger.info(`通知创建成功: ${title} (ID: ${result.insertId})`);
      return notifications[0];
    } catch (error) {
      logger.error(`创建通知失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取所有系统通知
   * @returns {Promise<Array>} 通知列表
   */
  async getAllNotifications() {
    try {
      const [notifications] = await this.pool.query(
        'SELECT * FROM notifications ORDER BY created_at DESC'
      );
      
      logger.info(`获取所有通知: 共${notifications.length}条记录`);
      return notifications;
    } catch (error) {
      logger.error(`获取通知列表失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取单个通知
   * @param {number} notificationId - 通知ID
   * @returns {Promise<Object>} 通知对象
   */
  async getNotificationById(notificationId) {
    try {
      const [notifications] = await this.pool.query(
        'SELECT * FROM notifications WHERE id = ?',
        [notificationId]
      );

      if (notifications.length === 0) {
        throw new Error('通知不存在');
      }

      logger.info(`获取通知: ID ${notificationId}`);
      return notifications[0];
    } catch (error) {
      logger.error(`获取通知失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取用户的通知
   * @param {number} userId - 用户ID
   * @returns {Promise<Array>} 通知列表
   */
  async getUserNotifications(userId) {
    try {
      const [notifications] = await this.pool.query(
        'SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC',
        [userId]
      );
      
      logger.info(`获取用户ID ${userId} 的通知: 共${notifications.length}条记录`);
      return notifications;
    } catch (error) {
      logger.error(`获取用户通知失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 更新通知
   * @param {number} notificationId - 通知ID
   * @param {Object} notificationData - 更新的通知数据
   * @returns {Promise<Object>} 更新后的通知对象
   */
  async updateNotification(notificationId, notificationData) {
    const { title, content, level } = notificationData;

    try {
      // 检查通知是否存在
      const [notifications] = await this.pool.query(
        'SELECT * FROM notifications WHERE id = ?',
        [notificationId]
      );

      if (notifications.length === 0) {
        throw new Error('通知不存在');
      }

      // 更新通知数据
      await this.pool.query(
        `UPDATE notifications SET 
         title = IFNULL(?, title),
         content = IFNULL(?, content),
         level = IFNULL(?, level)
         WHERE id = ?`,
        [title, content, level, notificationId]
      );

      // 获取更新后的通知
      const [updatedNotifications] = await this.pool.query(
        'SELECT * FROM notifications WHERE id = ?',
        [notificationId]
      );

      logger.info(`通知更新成功: ID ${notificationId}`);
      return updatedNotifications[0];
    } catch (error) {
      logger.error(`更新通知失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 删除通知
   * @param {number} notificationId - 通知ID
   * @returns {Promise<boolean>} 是否成功删除
   */
  async deleteNotification(notificationId) {
    try {
      // 检查通知是否存在
      const [notifications] = await this.pool.query(
        'SELECT id FROM notifications WHERE id = ?',
        [notificationId]
      );

      if (notifications.length === 0) {
        throw new Error('通知不存在');
      }

      // 删除通知
      await this.pool.query('DELETE FROM notifications WHERE id = ?', [notificationId]);

      logger.info(`通知删除成功: ID ${notificationId}`);
      return true;
    } catch (error) {
      logger.error(`删除通知失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 按级别获取通知
   * @param {string} level - 通知级别 (low/medium/high)
   * @returns {Promise<Array>} 通知列表
   */
  async getNotificationsByLevel(level) {
    try {
      const [notifications] = await this.pool.query(
        'SELECT * FROM notifications WHERE level = ? ORDER BY created_at DESC',
        [level]
      );
      
      logger.info(`获取级别 ${level} 的通知: 共${notifications.length}条记录`);
      return notifications;
    } catch (error) {
      logger.error(`获取级别通知失败: ${error.message}`);
      throw error;
    }
  }
}

module.exports = NotificationService;
