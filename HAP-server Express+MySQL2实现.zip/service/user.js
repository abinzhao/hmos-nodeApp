/**
 * 用户服务模块
 */
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { jwt: jwtConfig } = require('../config/config');
const logger = require('../utils/logger');

/**
 * 用户服务类
 */
class UserService {
  /**
   * 构造函数
   * @param {mysql.Pool} pool - MySQL连接池
   */
  constructor(pool) {
    this.pool = pool;
  }

  /**
   * 创建新用户
   * @param {Object} userData - 用户数据
   * @returns {Promise<Object>} 创建的用户对象(不含密码)
   */
  async createUser(userData) {
    const { username, password, gender, bio, tags, phone, email, openid, is_admin } = userData;

    try {
      // 检查用户名是否已存在
      const [existingUsers] = await this.pool.query(
        'SELECT id FROM users WHERE username = ?',
        [username]
      );

      if (existingUsers.length > 0) {
        throw new Error('用户名已存在');
      }

      // 加密密码
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);

      // 插入用户数据
      const [result] = await this.pool.query(
        `INSERT INTO users (username, password, gender, bio, tags, phone, email, openid, is_admin) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [username, hashedPassword, gender, bio, tags, phone, email, openid, is_admin || false]
      );

      // 获取创建的用户
      const [users] = await this.pool.query(
        'SELECT id, username, gender, bio, tags, phone, email, openid, created_at, is_admin FROM users WHERE id = ?',
        [result.insertId]
      );

      logger.info(`用户创建成功: ${username} (ID: ${result.insertId})`);
      return users[0];
    } catch (error) {
      logger.error(`创建用户失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 用户登录
   * @param {string} username - 用户名
   * @param {string} password - 密码
   * @returns {Promise<Object>} 包含用户信息和JWT令牌
   */
  async loginUser(username, password) {
    try {
      // 查找用户
      const [users] = await this.pool.query(
        'SELECT * FROM users WHERE username = ?',
        [username]
      );

      if (users.length === 0) {
        throw new Error('用户不存在');
      }

      const user = users[0];

      // 验证密码
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        throw new Error('密码错误');
      }

      // 创建JWT令牌
      const payload = {
        id: user.id,
        username: user.username,
        isAdmin: user.is_admin
      };

      const token = jwt.sign(payload, jwtConfig.secret, {
        expiresIn: jwtConfig.expiresIn
      });

      // 不返回密码
      delete user.password;

      logger.info(`用户登录成功: ${username} (ID: ${user.id})`);
      return {
        user,
        token
      };
    } catch (error) {
      logger.error(`用户登录失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取所有用户
   * @returns {Promise<Array>} 用户列表
   */
  async getAllUsers() {
    try {
      const [users] = await this.pool.query(
        'SELECT id, username, gender, bio, tags, phone, email, openid, created_at FROM users'
      );
      
      logger.info(`获取所有用户: 共${users.length}条记录`);
      return users;
    } catch (error) {
      logger.error(`获取用户列表失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取单个用户
   * @param {number} userId - 用户ID
   * @returns {Promise<Object>} 用户对象
   */
  async getUserById(userId) {
    try {
      const [users] = await this.pool.query(
        'SELECT id, username, gender, bio, tags, phone, email, openid, created_at FROM users WHERE id = ?',
        [userId]
      );

      if (users.length === 0) {
        throw new Error('用户不存在');
      }

      logger.info(`获取用户: ID ${userId}`);
      return users[0];
    } catch (error) {
      logger.error(`获取用户失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 更新用户信息
   * @param {number} userId - 用户ID
   * @param {Object} userData - 更新的用户数据
   * @returns {Promise<Object>} 更新后的用户对象
   */
  async updateUser(userId, userData) {
    const { username, gender, bio, tags, phone, email, password } = userData;

    try {
      // 检查用户是否存在
      const [users] = await this.pool.query(
        'SELECT * FROM users WHERE id = ?',
        [userId]
      );

      if (users.length === 0) {
        throw new Error('用户不存在');
      }

      let hashedPassword = users[0].password;
      
      // 如果提供了新密码，则加密
      if (password) {
        const salt = await bcrypt.genSalt(10);
        hashedPassword = await bcrypt.hash(password, salt);
      }

      // 更新用户数据
      await this.pool.query(
        `UPDATE users SET 
         username = IFNULL(?, username),
         gender = IFNULL(?, gender),
         bio = IFNULL(?, bio),
         tags = IFNULL(?, tags),
         phone = IFNULL(?, phone),
         email = IFNULL(?, email),
         password = ?
         WHERE id = ?`,
        [username, gender, bio, tags, phone, email, hashedPassword, userId]
      );

      // 获取更新后的用户
      const [updatedUsers] = await this.pool.query(
        'SELECT id, username, gender, bio, tags, phone, email, openid, created_at FROM users WHERE id = ?',
        [userId]
      );

      logger.info(`用户更新成功: ID ${userId}`);
      return updatedUsers[0];
    } catch (error) {
      logger.error(`更新用户失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 删除用户
   * @param {number} userId - 用户ID
   * @returns {Promise<boolean>} 是否成功删除
   */
  async deleteUser(userId) {
    try {
      // 检查用户是否存在
      const [users] = await this.pool.query(
        'SELECT id FROM users WHERE id = ?',
        [userId]
      );

      if (users.length === 0) {
        throw new Error('用户不存在');
      }

      // 删除用户
      await this.pool.query('DELETE FROM users WHERE id = ?', [userId]);

      logger.info(`用户删除成功: ID ${userId}`);
      return true;
    } catch (error) {
      logger.error(`删除用户失败: ${error.message}`);
      throw error;
    }
  }
}

module.exports = UserService;
