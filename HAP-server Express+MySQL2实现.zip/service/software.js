/**
 * 软件服务模块
 */
const logger = require('../utils/logger');

/**
 * 软件服务类
 */
class SoftwareService {
  /**
   * 构造函数
   * @param {mysql.Pool} pool - MySQL连接池
   */
  constructor(pool) {
    this.pool = pool;
  }

  /**
   * 创建新软件
   * @param {Object} softwareData - 软件数据
   * @returns {Promise<Object>} 创建的软件对象
   */
  async createSoftware(softwareData) {
    const { 
      package_name, version, name, icon, description, 
      update_info, screenshot1, screenshot2, screenshot3, screenshot4, 
      user_id, category, tags 
    } = softwareData;

    try {
      // 插入软件数据
      const [result] = await this.pool.query(
        `INSERT INTO softwares 
         (package_name, version, name, icon, description, update_info, 
          screenshot1, screenshot2, screenshot3, screenshot4, 
          user_id, category, tags) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          package_name, version, name, icon, description, update_info, 
          screenshot1 || null, screenshot2 || null, screenshot3 || null, screenshot4 || null, 
          user_id, category, tags
        ]
      );

      // 获取创建的软件
      const [softwares] = await this.pool.query(
        'SELECT * FROM softwares WHERE id = ?',
        [result.insertId]
      );

      logger.info(`软件创建成功: ${name} (${package_name}) (ID: ${result.insertId})`);
      return softwares[0];
    } catch (error) {
      logger.error(`创建软件失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取所有软件
   * @returns {Promise<Array>} 软件列表
   */
  async getAllSoftwares() {
    try {
      const [softwares] = await this.pool.query(
        'SELECT * FROM softwares ORDER BY upload_time DESC'
      );
      
      logger.info(`获取所有软件: 共${softwares.length}条记录`);
      return softwares;
    } catch (error) {
      logger.error(`获取软件列表失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取单个软件
   * @param {number} softwareId - 软件ID
   * @returns {Promise<Object>} 软件对象
   */
  async getSoftwareById(softwareId) {
    try {
      const [softwares] = await this.pool.query(
        'SELECT * FROM softwares WHERE id = ?',
        [softwareId]
      );

      if (softwares.length === 0) {
        throw new Error('软件不存在');
      }

      logger.info(`获取软件: ID ${softwareId}`);
      return softwares[0];
    } catch (error) {
      logger.error(`获取软件失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取用户的软件
   * @param {number} userId - 用户ID
   * @returns {Promise<Array>} 软件列表
   */
  async getUserSoftwares(userId) {
    try {
      const [softwares] = await this.pool.query(
        'SELECT * FROM softwares WHERE user_id = ? ORDER BY upload_time DESC',
        [userId]
      );
      
      logger.info(`获取用户ID ${userId} 的软件: 共${softwares.length}条记录`);
      return softwares;
    } catch (error) {
      logger.error(`获取用户软件失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 更新软件信息
   * @param {number} softwareId - 软件ID
   * @param {Object} softwareData - 更新的软件数据
   * @returns {Promise<Object>} 更新后的软件对象
   */
  async updateSoftware(softwareId, softwareData) {
    const { 
      version, name, icon, description, update_info,
      screenshot1, screenshot2, screenshot3, screenshot4,
      category, tags 
    } = softwareData;

    try {
      // 检查软件是否存在
      const [softwares] = await this.pool.query(
        'SELECT * FROM softwares WHERE id = ?',
        [softwareId]
      );

      if (softwares.length === 0) {
        throw new Error('软件不存在');
      }

      // 更新软件数据
      await this.pool.query(
        `UPDATE softwares SET 
         version = IFNULL(?, version),
         name = IFNULL(?, name),
         icon = IFNULL(?, icon),
         description = IFNULL(?, description),
         update_info = IFNULL(?, update_info),
         screenshot1 = IFNULL(?, screenshot1),
         screenshot2 = IFNULL(?, screenshot2),
         screenshot3 = IFNULL(?, screenshot3),
         screenshot4 = IFNULL(?, screenshot4),
         category = IFNULL(?, category),
         tags = IFNULL(?, tags)
         WHERE id = ?`,
        [
          version, name, icon, description, update_info,
          screenshot1, screenshot2, screenshot3, screenshot4,
          category, tags, softwareId
        ]
      );

      // 获取更新后的软件
      const [updatedSoftwares] = await this.pool.query(
        'SELECT * FROM softwares WHERE id = ?',
        [softwareId]
      );

      logger.info(`软件更新成功: ID ${softwareId}`);
      return updatedSoftwares[0];
    } catch (error) {
      logger.error(`更新软件失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 删除软件
   * @param {number} softwareId - 软件ID
   * @returns {Promise<boolean>} 是否成功删除
   */
  async deleteSoftware(softwareId) {
    try {
      // 检查软件是否存在
      const [softwares] = await this.pool.query(
        'SELECT id FROM softwares WHERE id = ?',
        [softwareId]
      );

      if (softwares.length === 0) {
        throw new Error('软件不存在');
      }

      // 删除软件
      await this.pool.query('DELETE FROM softwares WHERE id = ?', [softwareId]);

      logger.info(`软件删除成功: ID ${softwareId}`);
      return true;
    } catch (error) {
      logger.error(`删除软件失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 增加软件下载次数
   * @param {number} softwareId - 软件ID
   * @returns {Promise<number>} 更新后的下载次数
   */
  async incrementDownload(softwareId) {
    try {
      // 检查软件是否存在
      const [softwares] = await this.pool.query(
        'SELECT id, download_count FROM softwares WHERE id = ?',
        [softwareId]
      );

      if (softwares.length === 0) {
        throw new Error('软件不存在');
      }

      const newCount = softwares[0].download_count + 1;

      // 更新下载次数
      await this.pool.query(
        'UPDATE softwares SET download_count = ? WHERE id = ?',
        [newCount, softwareId]
      );

      logger.info(`软件下载次数增加: ID ${softwareId}, 新下载次数: ${newCount}`);
      return newCount;
    } catch (error) {
      logger.error(`更新软件下载次数失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 按类别获取软件
   * @param {string} category - 软件类别
   * @returns {Promise<Array>} 软件列表
   */
  async getSoftwaresByCategory(category) {
    try {
      const [softwares] = await this.pool.query(
        'SELECT * FROM softwares WHERE category = ? ORDER BY upload_time DESC',
        [category]
      );
      
      logger.info(`获取类别 ${category} 的软件: 共${softwares.length}条记录`);
      return softwares;
    } catch (error) {
      logger.error(`获取类别软件失败: ${error.message}`);
      throw error;
    }
  }
}

module.exports = SoftwareService;
