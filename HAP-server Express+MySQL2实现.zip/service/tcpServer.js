/**
 * TCP服务器模块
 * 
 * 用于处理远程终端TCP连接和命令执行
 */
const net = require('net');
const { exec } = require('child_process');
const logger = require('../utils/logger');

/**
 * TCP服务器类
 */
class TcpServer {
  /**
   * 构造函数
   * @param {Object} options - 服务器配置选项
   * @param {number} options.port - TCP服务器端口
   * @param {string[]} options.allowedCommands - 允许执行的命令前缀列表
   */
  constructor(options = {}) {
    this.port = options.port || 8888;
    this.allowedCommands = options.allowedCommands || ['adb', 'hdc'];
    this.server = null;
    this.clients = new Map(); // 存储客户端连接，键为客户端ID
    this.nextClientId = 1;
  }

  /**
   * 启动TCP服务器
   * @returns {Promise<void>}
   */
  start() {
    return new Promise((resolve, reject) => {
      try {
        // 创建TCP服务器
        this.server = net.createServer((socket) => {
          this.handleConnection(socket);
        });

        // 监听错误事件
        this.server.on('error', (err) => {
          logger.error(`TCP服务器错误: ${err.message}`);
          reject(err);
        });

        // 启动监听
        this.server.listen(this.port, () => {
          logger.info(`TCP服务器已启动，监听端口 ${this.port}`);
          resolve();
        });
      } catch (error) {
        logger.error(`启动TCP服务器失败: ${error.message}`);
        reject(error);
      }
    });
  }

  /**
   * 停止TCP服务器
   * @returns {Promise<void>}
   */
  stop() {
    return new Promise((resolve) => {
      if (!this.server) {
        return resolve();
      }

      // 关闭所有客户端连接
      for (const [clientId, client] of this.clients.entries()) {
        try {
          client.socket.end('服务器关闭');
          client.socket.destroy();
          this.clients.delete(clientId);
        } catch (error) {
          logger.error(`关闭客户端 ${clientId} 连接失败: ${error.message}`);
        }
      }

      // 关闭服务器
      this.server.close(() => {
        logger.info('TCP服务器已关闭');
        this.server = null;
        resolve();
      });
    });
  }

  /**
   * 处理新的客户端连接
   * @param {net.Socket} socket - 客户端Socket
   */
  handleConnection(socket) {
    const clientId = this.nextClientId++;
    const clientAddress = `${socket.remoteAddress}:${socket.remotePort}`;
    
    logger.info(`新的客户端连接 [${clientId}]: ${clientAddress}`);
    
    // 存储客户端信息
    this.clients.set(clientId, {
      socket,
      address: clientAddress,
      buffer: '', // 缓存不完整的命令
      commandInProgress: false, // 标记是否有命令正在执行
      connectedAt: new Date(), // 连接时间
      commandsExecuted: 0, // 已执行命令数
      lastActivity: new Date() // 最后活动时间
    });

    // 发送欢迎消息
    socket.write(`欢迎连接到HAP-Server TCP命令服务器\r\n`);
    socket.write(`您的客户端ID: ${clientId}\r\n`);
    socket.write(`支持的命令前缀: ${this.allowedCommands.join(', ')}\r\n`);
    socket.write(`输入 'exit' 或 'quit' 断开连接\r\n`);
    socket.write(`> `);

    // 处理数据接收
    socket.on('data', (data) => {
      this.handleData(clientId, data);
    });

    // 处理连接关闭
    socket.on('close', () => {
      logger.info(`客户端 [${clientId}] 连接关闭: ${clientAddress}`);
      this.clients.delete(clientId);
    });

    // 处理连接错误
    socket.on('error', (err) => {
      logger.error(`客户端 [${clientId}] 连接错误: ${err.message}`);
      this.clients.delete(clientId);
    });
  }

  /**
   * 处理接收到的数据
   * @param {number} clientId - 客户端ID
   * @param {Buffer} data - 接收到的数据
   */
  handleData(clientId, data) {
    const client = this.clients.get(clientId);
    if (!client) return;

    // 将Buffer转换为字符串并添加到缓冲区
    client.buffer += data.toString();

    // 检查是否有完整的命令行（以换行符结束）
    const lines = client.buffer.split('\n');
    
    // 如果最后一行不完整（没有换行符），保留在缓冲区
    client.buffer = lines.pop();

    // 处理完整的命令行
    for (const line of lines) {
      const command = line.trim();
      
      // 忽略空命令
      if (!command) continue;
      
      // 处理退出命令
      if (command.toLowerCase() === 'exit' || command.toLowerCase() === 'quit') {
        client.socket.write('再见!\r\n');
        client.socket.end();
        return;
      }

      // 执行命令
      this.executeCommand(clientId, command);
    }
  }

  /**
   * 执行命令
   * @param {number} clientId - 客户端ID
   * @param {string} command - 要执行的命令
   */
  executeCommand(clientId, command) {
    const client = this.clients.get(clientId);
    if (!client) return;

    // 如果已经有命令在执行，则排队
    if (client.commandInProgress) {
      client.socket.write(`命令已排队: ${command}\r\n`);
      client.commandQueue = client.commandQueue || [];
      client.commandQueue.push(command);
      return;
    }

    // 验证命令是否允许执行
    const isAllowed = this.allowedCommands.some(prefix => command.startsWith(prefix));
    if (!isAllowed) {
      client.socket.write(`错误: 不允许的命令。只允许以下前缀: ${this.allowedCommands.join(', ')}\r\n> `);
      return;
    }

    // 标记命令正在执行
    client.commandInProgress = true;
    client.lastActivity = new Date();
    client.commandsExecuted = (client.commandsExecuted || 0) + 1;
    
    // 记录命令执行
    logger.info(`客户端 [${clientId}] 执行命令: ${command}`);
    client.socket.write(`执行命令: ${command}\r\n`);

    // 执行命令
    exec(command, (error, stdout, stderr) => {
      // 命令执行完成
      client.commandInProgress = false;
      
      if (error) {
        client.socket.write(`执行错误: ${error.message}\r\n`);
      }

      if (stderr) {
        client.socket.write(`STDERR:\r\n${stderr}\r\n`);
      }

      if (stdout) {
        client.socket.write(`STDOUT:\r\n${stdout}\r\n`);
      }

      client.socket.write('> ');

      // 检查是否有排队的命令
      if (client.commandQueue && client.commandQueue.length > 0) {
        const nextCommand = client.commandQueue.shift();
        process.nextTick(() => {
          this.executeCommand(clientId, nextCommand);
        });
      }
    });
  }

  /**
   * 向所有客户端广播消息
   * @param {string} message - 要广播的消息
   */
  broadcast(message) {
    for (const [clientId, client] of this.clients.entries()) {
      try {
        client.socket.write(`[广播] ${message}\r\n> `);
      } catch (error) {
        logger.error(`向客户端 ${clientId} 广播失败: ${error.message}`);
      }
    }
  }

  /**
   * 向特定客户端发送消息
   * @param {number} clientId - 客户端ID
   * @param {string} message - 要发送的消息
   * @returns {boolean} 是否发送成功
   */
  sendMessageToClient(clientId, message) {
    const client = this.clients.get(clientId);
    if (!client) {
      return false;
    }

    try {
      client.socket.write(`[服务器] ${message}\r\n> `);
      return true;
    } catch (error) {
      logger.error(`向客户端 ${clientId} 发送消息失败: ${error.message}`);
      return false;
    }
  }

  /**
   * 断开特定客户端的连接
   * @param {number} clientId - 客户端ID
   * @returns {boolean} 是否断开成功
   */
  disconnectClient(clientId) {
    const client = this.clients.get(clientId);
    if (!client) {
      return false;
    }

    try {
      client.socket.end('服务器已断开连接\r\n');
      client.socket.destroy();
      this.clients.delete(clientId);
      logger.info(`已手动断开客户端 ${clientId} 的连接`);
      return true;
    } catch (error) {
      logger.error(`断开客户端 ${clientId} 连接失败: ${error.message}`);
      return false;
    }
  }

  /**
   * 获取当前连接的客户端数量
   * @returns {number} 客户端数量
   */
  getClientCount() {
    return this.clients.size;
  }

  /**
   * 获取客户端列表
   * @returns {Array} 客户端信息列表
   */
  getClientList() {
    const clientList = [];
    for (const [clientId, client] of this.clients.entries()) {
      clientList.push({
        id: clientId,
        address: client.address,
        connectedAt: client.connectedAt || new Date(),
        commandsExecuted: client.commandsExecuted || 0
      });
    }
    return clientList;
  }

  /**
   * 更新允许执行的命令前缀列表
   * @param {string[]} commands - 命令前缀列表
   */
  setAllowedCommands(commands) {
    if (Array.isArray(commands) && commands.length > 0) {
      this.allowedCommands = commands;
      logger.info(`已更新允许执行的命令前缀: ${commands.join(', ')}`);
    }
  }
}

module.exports = TcpServer;
