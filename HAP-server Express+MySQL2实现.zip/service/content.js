/**
 * 内容服务模块
 */
const logger = require('../utils/logger');

/**
 * 内容服务类
 */
class ContentService {
  /**
   * 构造函数
   * @param {mysql.Pool} pool - MySQL连接池
   */
  constructor(pool) {
    this.pool = pool;
  }

  /**
   * 创建新内容
   * @param {Object} contentData - 内容数据
   * @returns {Promise<Object>} 创建的内容对象
   */
  async createContent(contentData) {
    const { type, title, description, content, tags, user_id, category } = contentData;

    try {
      // 插入内容数据
      const [result] = await this.pool.query(
        `INSERT INTO contents (type, title, description, content, tags, user_id, category) 
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [type, title, description, content, tags, user_id, category]
      );

      // 获取创建的内容
      const [contents] = await this.pool.query(
        'SELECT * FROM contents WHERE id = ?',
        [result.insertId]
      );

      logger.info(`内容创建成功: ${type} - ${title} (ID: ${result.insertId})`);
      return contents[0];
    } catch (error) {
      logger.error(`创建内容失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取所有内容
   * @param {string} type - 内容类型 (post/code)
   * @returns {Promise<Array>} 内容列表
   */
  async getAllContents(type = null) {
    try {
      let query = 'SELECT * FROM contents';
      const params = [];
      
      if (type) {
        query += ' WHERE type = ?';
        params.push(type);
      }
      
      query += ' ORDER BY created_at DESC';
      
      const [contents] = await this.pool.query(query, params);
      
      logger.info(`获取${type ? type + '类型' : '所有'}内容: 共${contents.length}条记录`);
      return contents;
    } catch (error) {
      logger.error(`获取内容列表失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取单个内容
   * @param {number} contentId - 内容ID
   * @returns {Promise<Object>} 内容对象
   */
  async getContentById(contentId) {
    try {
      const [contents] = await this.pool.query(
        'SELECT * FROM contents WHERE id = ?',
        [contentId]
      );

      if (contents.length === 0) {
        throw new Error('内容不存在');
      }

      logger.info(`获取内容: ID ${contentId}`);
      return contents[0];
    } catch (error) {
      logger.error(`获取内容失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 获取用户的内容
   * @param {number} userId - 用户ID
   * @param {string} type - 内容类型 (post/code)
   * @returns {Promise<Array>} 内容列表
   */
  async getUserContents(userId, type = null) {
    try {
      let query = 'SELECT * FROM contents WHERE user_id = ?';
      const params = [userId];
      
      if (type) {
        query += ' AND type = ?';
        params.push(type);
      }
      
      query += ' ORDER BY created_at DESC';
      
      const [contents] = await this.pool.query(query, params);
      
      logger.info(`获取用户ID ${userId} 的${type ? type + '类型' : '所有'}内容: 共${contents.length}条记录`);
      return contents;
    } catch (error) {
      logger.error(`获取用户内容失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 更新内容
   * @param {number} contentId - 内容ID
   * @param {Object} contentData - 更新的内容数据
   * @returns {Promise<Object>} 更新后的内容对象
   */
  async updateContent(contentId, contentData) {
    const { title, description, content, tags, category } = contentData;

    try {
      // 检查内容是否存在
      const [contents] = await this.pool.query(
        'SELECT * FROM contents WHERE id = ?',
        [contentId]
      );

      if (contents.length === 0) {
        throw new Error('内容不存在');
      }

      // 更新内容数据
      await this.pool.query(
        `UPDATE contents SET 
         title = IFNULL(?, title),
         description = IFNULL(?, description),
         content = IFNULL(?, content),
         tags = IFNULL(?, tags),
         category = IFNULL(?, category)
         WHERE id = ?`,
        [title, description, content, tags, category, contentId]
      );

      // 获取更新后的内容
      const [updatedContents] = await this.pool.query(
        'SELECT * FROM contents WHERE id = ?',
        [contentId]
      );

      logger.info(`内容更新成功: ID ${contentId}`);
      return updatedContents[0];
    } catch (error) {
      logger.error(`更新内容失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 删除内容
   * @param {number} contentId - 内容ID
   * @returns {Promise<boolean>} 是否成功删除
   */
  async deleteContent(contentId) {
    try {
      // 检查内容是否存在
      const [contents] = await this.pool.query(
        'SELECT id FROM contents WHERE id = ?',
        [contentId]
      );

      if (contents.length === 0) {
        throw new Error('内容不存在');
      }

      // 删除内容
      await this.pool.query('DELETE FROM contents WHERE id = ?', [contentId]);

      logger.info(`内容删除成功: ID ${contentId}`);
      return true;
    } catch (error) {
      logger.error(`删除内容失败: ${error.message}`);
      throw error;
    }
  }

  /**
   * 按类别获取内容
   * @param {string} category - 内容类别
   * @param {string} type - 内容类型 (post/code)
   * @returns {Promise<Array>} 内容列表
   */
  async getContentsByCategory(category, type = null) {
    try {
      let query = 'SELECT * FROM contents WHERE category = ?';
      const params = [category];
      
      if (type) {
        query += ' AND type = ?';
        params.push(type);
      }
      
      query += ' ORDER BY created_at DESC';
      
      const [contents] = await this.pool.query(query, params);
      
      logger.info(`获取类别 ${category} 的${type ? type + '类型' : '所有'}内容: 共${contents.length}条记录`);
      return contents;
    } catch (error) {
      logger.error(`获取类别内容失败: ${error.message}`);
      throw error;
    }
  }
}

module.exports = ContentService;
