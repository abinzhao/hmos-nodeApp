# HAP-Server

基于Express和MySQL2构建的功能完整的后端服务器。

## 项目概述

HAP-Server是一个功能完整的后端服务器，提供用户管理、文件上传、内容管理、软件包管理、留言管理和系统通知等功能。该服务器使用Express框架和MySQL数据库，具有清晰的项目结构和高度的可配置性。

## 技术栈

- **Node.js**: JavaScript运行时环境
- **Express**: Web应用框架
- **MySQL2**: MySQL数据库驱动
- **JWT**: JSON Web Token用于身份验证
- **Bcrypt**: 密码加密
- **Multer**: 文件上传处理
- **Winston**: 日志记录
- **Helmet**: 安全增强中间件
- **CORS**: 跨域资源共享

## 项目结构

```
HAP-server/
├── config/                # 配置文件
│   ├── config.js          # 应用配置
│   └── database.js        # 数据库配置
├── middlewares/           # 中间件
│   ├── auth.js            # 认证中间件
│   └── errorHandler.js    # 错误处理中间件
├── service/               # 接口服务
│   ├── user.js            # 用户服务
│   ├── content.js         # 内容服务
│   ├── software.js        # 软件服务
│   ├── comment.js         # 留言服务
│   └── notification.js    # 通知服务
├── routes/                # 路由
│   ├── user.js            # 用户路由
│   ├── file.js            # 文件上传路由
│   ├── content.js         # 内容路由
│   ├── software.js        # 软件路由
│   ├── comment.js         # 留言路由
│   └── notification.js    # 通知路由
├── utils/                 # 工具函数
│   ├── dbSetup.js         # 数据库初始化
│   ├── logger.js          # 日志工具
│   └── portChecker.js     # 端口检查工具
├── public/                # 静态文件
│   └── index.html         # 示例HTML
├── FileData/              # 上传文件存储
│   ├── HAP-app/           # 应用文件存储
│   └── HAP-image/         # 图片文件存储
├── logs/                  # 日志文件
├── app.js                 # 主应用文件
├── server.js              # 服务器启动文件
└── README.md              # 项目文档
```

## 数据库结构

HAP-Server使用MySQL数据库，包含以下数据表：

1. **用户表 (users)**
   - 用户ID (id)
   - 用户名 (username)
   - OpenID (openid)
   - 用户性别 (gender)
   - 用户简介 (bio)
   - 用户标签 (tags)
   - 用户密码 (password)
   - 创建时间 (created_at)
   - 手机号 (phone)
   - 邮箱 (email)

2. **内容表 (contents)**
   - 内容ID (id)
   - 内容类型 (type) - 帖子/代码片段
   - 内容标题 (title)
   - 内容描述 (description)
   - 内容正文 (content)
   - 内容标签 (tags)
   - 用户ID (user_id)
   - 创建时间 (created_at)
   - 内容分类 (category)

3. **软件表 (softwares)**
   - 软件ID (id)
   - 软件包名 (package_name)
   - 包版本 (version)
   - 软件名 (name)
   - 软件图标 (icon)
   - 软件介绍 (description)
   - 更新详情 (update_info)
   - 软件截图 (screenshots)
   - 用户ID (user_id)
   - 上传时间 (upload_time)
   - 下载次数 (download_count)
   - 软件分类 (category)
   - 软件标签 (tags)

4. **留言表 (comments)**
   - 留言ID (id)
   - 内容ID (content_id)
   - 软件ID (software_id)
   - 留言用户ID (user_id)
   - 留言内容 (content)
   - 创建时间 (created_at)

5. **系统通知表 (notifications)**
   - 通知ID (id)
   - 通知标题 (title)
   - 通知内容 (content)
   - 通知级别 (level) - 低/中/高
   - 创建时间 (created_at)
   - 用户ID (user_id)

## 安装与运行

### 前提条件

- Node.js (v14+)
- MySQL (v5.7+)

### 安装步骤

1. 克隆代码库
```bash
git clone https://github.com/yourusername/hap-server.git
cd hap-server
```

2. 安装依赖
```bash
npm install
```

3. 配置环境变量
创建 `.env` 文件并设置以下变量：
```
PORT=3000
NODE_ENV=development
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=HMOS-SQL
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRE=24h
UPLOAD_APP_PATH=FileData/HAP-app
UPLOAD_IMAGE_PATH=FileData/HAP-image
```

4. 启动服务器
```bash
npm start
```

服务器将在指定端口（默认3000）上启动，并自动创建必要的数据库和表。

## API 文档

### 用户API

#### 注册用户
- **URL**: `/api/users/register`
- **方法**: `POST`
- **请求体**:
  ```json
  {
    "username": "testuser",
    "password": "password123",
    "gender": "male",
    "bio": "用户简介",
    "tags": "标签1,标签2",
    "phone": "13800138000",
    "email": "user@example.com"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "username": "testuser",
      "gender": "male",
      "bio": "用户简介",
      "tags": "标签1,标签2",
      "phone": "13800138000",
      "email": "user@example.com",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 用户登录
- **URL**: `/api/users/login`
- **方法**: `POST`
- **请求体**:
  ```json
  {
    "username": "testuser",
    "password": "password123"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "user": {
        "id": 1,
        "username": "testuser",
        "gender": "male",
        "bio": "用户简介",
        "tags": "标签1,标签2",
        "phone": "13800138000",
        "email": "user@example.com",
        "created_at": "2023-01-01T00:00:00.000Z"
      },
      "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
    }
  }
  ```

#### 获取所有用户
- **URL**: `/api/users`
- **方法**: `GET`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 1,
        "username": "testuser",
        "gender": "male",
        "bio": "用户简介",
        "tags": "标签1,标签2",
        "phone": "13800138000",
        "email": "user@example.com",
        "created_at": "2023-01-01T00:00:00.000Z"
      }
    ]
  }
  ```

#### 获取单个用户
- **URL**: `/api/users/:id`
- **方法**: `GET`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "username": "testuser",
      "gender": "male",
      "bio": "用户简介",
      "tags": "标签1,标签2",
      "phone": "13800138000",
      "email": "user@example.com",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 更新用户
- **URL**: `/api/users/:id`
- **方法**: `PUT`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "bio": "更新的用户简介",
    "tags": "标签1,标签2,标签3"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "username": "testuser",
      "gender": "male",
      "bio": "更新的用户简介",
      "tags": "标签1,标签2,标签3",
      "phone": "13800138000",
      "email": "user@example.com",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 删除用户
- **URL**: `/api/users/:id`
- **方法**: `DELETE`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "message": "用户已成功删除"
  }
  ```

### 文件上传API

#### 上传单个文件
- **URL**: `/api/files/upload`
- **方法**: `POST`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**: `FormData` 包含字段 `file`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "filename": "file-1234567890.jpg",
      "originalName": "example.jpg",
      "mimetype": "image/jpeg",
      "size": 12345,
      "url": "http://localhost:3000/FileData/HAP-image/file-1234567890.jpg"
    }
  }
  ```

#### 上传多个文件
- **URL**: `/api/files/upload/multiple`
- **方法**: `POST`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**: `FormData` 包含字段 `files`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "filename": "file-1234567890.jpg",
        "originalName": "example1.jpg",
        "mimetype": "image/jpeg",
        "size": 12345,
        "url": "http://localhost:3000/FileData/HAP-image/file-1234567890.jpg"
      },
      {
        "filename": "file-0987654321.hap",
        "originalName": "example.hap",
        "mimetype": "application/octet-stream",
        "size": 54321,
        "url": "http://localhost:3000/FileData/HAP-app/file-0987654321.hap"
      }
    ]
  }
  ```

### 内容API

#### 创建内容
- **URL**: `/api/contents`
- **方法**: `POST`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "type": "post",
    "title": "测试标题",
    "description": "测试描述",
    "content": "测试内容",
    "tags": "标签1,标签2",
    "category": "技术"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "type": "post",
      "title": "测试标题",
      "description": "测试描述",
      "content": "测试内容",
      "tags": "标签1,标签2",
      "user_id": 1,
      "category": "技术",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 获取所有内容
- **URL**: `/api/contents?type=post`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 1,
        "type": "post",
        "title": "测试标题",
        "description": "测试描述",
        "content": "测试内容",
        "tags": "标签1,标签2",
        "user_id": 1,
        "category": "技术",
        "created_at": "2023-01-01T00:00:00.000Z"
      }
    ]
  }
  ```

#### 获取单个内容
- **URL**: `/api/contents/:id`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "type": "post",
      "title": "测试标题",
      "description": "测试描述",
      "content": "测试内容",
      "tags": "标签1,标签2",
      "user_id": 1,
      "category": "技术",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 更新内容
- **URL**: `/api/contents/:id`
- **方法**: `PUT`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "title": "更新的标题",
    "content": "更新的内容"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "type": "post",
      "title": "更新的标题",
      "description": "测试描述",
      "content": "更新的内容",
      "tags": "标签1,标签2",
      "user_id": 1,
      "category": "技术",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 删除内容
- **URL**: `/api/contents/:id`
- **方法**: `DELETE`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "message": "内容已成功删除"
  }
  ```

### 软件API

#### 创建软件
- **URL**: `/api/softwares`
- **方法**: `POST`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "package_name": "com.example.app",
    "version": "1.0.0",
    "name": "测试应用",
    "icon": "http://localhost:3000/FileData/HAP-image/icon.png",
    "description": "测试应用描述",
    "update_info": "首次发布",
    "screenshots": "http://localhost:3000/FileData/HAP-image/screen1.png,http://localhost:3000/FileData/HAP-image/screen2.png",
    "category": "工具",
    "tags": "标签1,标签2"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "package_name": "com.example.app",
      "version": "1.0.0",
      "name": "测试应用",
      "icon": "http://localhost:3000/FileData/HAP-image/icon.png",
      "description": "测试应用描述",
      "update_info": "首次发布",
      "screenshots": "http://localhost:3000/FileData/HAP-image/screen1.png,http://localhost:3000/FileData/HAP-image/screen2.png",
      "user_id": 1,
      "category": "工具",
      "tags": "标签1,标签2",
      "upload_time": "2023-01-01T00:00:00.000Z",
      "download_count": 0
    }
  }
  ```

#### 获取所有软件
- **URL**: `/api/softwares`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 1,
        "package_name": "com.example.app",
        "version": "1.0.0",
        "name": "测试应用",
        "icon": "http://localhost:3000/FileData/HAP-image/icon.png",
        "description": "测试应用描述",
        "update_info": "首次发布",
        "screenshots": "http://localhost:3000/FileData/HAP-image/screen1.png,http://localhost:3000/FileData/HAP-image/screen2.png",
        "user_id": 1,
        "category": "工具",
        "tags": "标签1,标签2",
        "upload_time": "2023-01-01T00:00:00.000Z",
        "download_count": 0
      }
    ]
  }
  ```

#### 获取单个软件
- **URL**: `/api/softwares/:id`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "package_name": "com.example.app",
      "version": "1.0.0",
      "name": "测试应用",
      "icon": "http://localhost:3000/FileData/HAP-image/icon.png",
      "description": "测试应用描述",
      "update_info": "首次发布",
      "screenshots": "http://localhost:3000/FileData/HAP-image/screen1.png,http://localhost:3000/FileData/HAP-image/screen2.png",
      "user_id": 1,
      "category": "工具",
      "tags": "标签1,标签2",
      "upload_time": "2023-01-01T00:00:00.000Z",
      "download_count": 0
    }
  }
  ```

#### 更新软件
- **URL**: `/api/softwares/:id`
- **方法**: `PUT`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "version": "1.0.1",
    "update_info": "修复bug"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "package_name": "com.example.app",
      "version": "1.0.1",
      "name": "测试应用",
      "icon": "http://localhost:3000/FileData/HAP-image/icon.png",
      "description": "测试应用描述",
      "update_info": "修复bug",
      "screenshots": "http://localhost:3000/FileData/HAP-image/screen1.png,http://localhost:3000/FileData/HAP-image/screen2.png",
      "user_id": 1,
      "category": "工具",
      "tags": "标签1,标签2",
      "upload_time": "2023-01-01T00:00:00.000Z",
      "download_count": 0
    }
  }
  ```

#### 删除软件
- **URL**: `/api/softwares/:id`
- **方法**: `DELETE`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "message": "软件已成功删除"
  }
  ```

#### 增加下载次数
- **URL**: `/api/softwares/:id/download`
- **方法**: `POST`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "download_count": 1
    }
  }
  ```

### 留言API

#### 创建留言
- **URL**: `/api/comments`
- **方法**: `POST`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "content_id": 1,
    "content": "测试留言"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "content_id": 1,
      "software_id": null,
      "user_id": 1,
      "content": "测试留言",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 获取内容留言
- **URL**: `/api/comments/content/:contentId`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 1,
        "content_id": 1,
        "software_id": null,
        "user_id": 1,
        "content": "测试留言",
        "created_at": "2023-01-01T00:00:00.000Z",
        "username": "testuser"
      }
    ]
  }
  ```

#### 获取软件留言
- **URL**: `/api/comments/software/:softwareId`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 2,
        "content_id": null,
        "software_id": 1,
        "user_id": 1,
        "content": "测试软件留言",
        "created_at": "2023-01-01T00:00:00.000Z",
        "username": "testuser"
      }
    ]
  }
  ```

#### 更新留言
- **URL**: `/api/comments/:id`
- **方法**: `PUT`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "content": "更新的留言内容"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "content_id": 1,
      "software_id": null,
      "user_id": 1,
      "content": "更新的留言内容",
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 删除留言
- **URL**: `/api/comments/:id`
- **方法**: `DELETE`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "message": "留言已成功删除"
  }
  ```

### 系统通知API

#### 创建通知
- **URL**: `/api/notifications`
- **方法**: `POST`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "title": "系统维护通知",
    "content": "系统将于今晚22:00-23:00进行维护",
    "level": "medium",
    "user_id": null
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "title": "系统维护通知",
      "content": "系统将于今晚22:00-23:00进行维护",
      "level": "medium",
      "user_id": null,
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 获取所有通知
- **URL**: `/api/notifications`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 1,
        "title": "系统维护通知",
        "content": "系统将于今晚22:00-23:00进行维护",
        "level": "medium",
        "user_id": null,
        "created_at": "2023-01-01T00:00:00.000Z"
      }
    ]
  }
  ```

#### 获取单个通知
- **URL**: `/api/notifications/:id`
- **方法**: `GET`
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "title": "系统维护通知",
      "content": "系统将于今晚22:00-23:00进行维护",
      "level": "medium",
      "user_id": null,
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 更新通知
- **URL**: `/api/notifications/:id`
- **方法**: `PUT`
- **请求头**: `Authorization: Bearer <token>`
- **请求体**:
  ```json
  {
    "title": "更新的通知标题",
    "level": "high"
  }
  ```
- **成功响应**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "title": "更新的通知标题",
      "content": "系统将于今晚22:00-23:00进行维护",
      "level": "high",
      "user_id": null,
      "created_at": "2023-01-01T00:00:00.000Z"
    }
  }
  ```

#### 删除通知
- **URL**: `/api/notifications/:id`
- **方法**: `DELETE`
- **请求头**: `Authorization: Bearer <token>`
- **成功响应**:
  ```json
  {
    "success": true,
    "message": "通知已成功删除"
  }
  ```

## 安全性

HAP-Server实现了多种安全措施：

1. **身份验证与授权**：使用JWT进行用户身份验证，确保API端点的安全访问。
2. **密码加密**：使用bcrypt对用户密码进行加密存储。
3. **安全头**：使用Helmet设置安全相关的HTTP头。
4. **输入验证**：使用express-validator对所有API输入进行验证和清理。
5. **错误处理**：全局错误处理中间件捕获并处理错误，防止敏感信息泄露。
6. **日志记录**：使用Winston记录服务器活动，便于监控和排错。
7. **文件上传限制**：对上传文件的类型和大小进行限制。

## 日志

服务器使用Winston进行日志记录，日志文件存储在`logs`目录下：

- `combined.log`：包含所有级别的日志
- `error.log`：只包含错误级别的日志

## 贡献

欢迎贡献代码或提出问题。请遵循以下步骤：

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 创建 Pull Request

## 许可证

此项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 联系方式

项目维护者: [your-email@example.com](mailto:your-email@example.com)

项目链接: [https://github.com/yourusername/hap-server](https://github.com/yourusername/hap-server)
