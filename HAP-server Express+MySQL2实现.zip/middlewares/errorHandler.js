/**
 * 错误处理中间件
 */
const logger = require('../utils/logger');

/**
 * 404错误处理
 * @param {Request} req - Express请求对象
 * @param {Response} res - Express响应对象
 */
const notFound = (req, res, next) => {
  logger.warn(`404 - 未找到路径: ${req.originalUrl}`);
  res.status(404).json({
    success: false,
    message: `找不到请求的资源: ${req.originalUrl}`
  });
};

/**
 * 全局错误处理
 * @param {Error} err - 错误对象
 * @param {Request} req - Express请求对象
 * @param {Response} res - Express响应对象
 * @param {NextFunction} next - Express下一个中间件函数
 */
const errorHandler = (err, req, res, next) => {
  // 确定状态码
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  
  // 记录错误日志
  logger.error(`${statusCode} - ${err.message}`);
  if (process.env.NODE_ENV === 'development') {
    logger.error(err.stack);
  }
  
  // 发送错误响应
  res.status(statusCode).json({
    success: false,
    message: err.message,
    stack: process.env.NODE_ENV === 'production' ? '🥞' : err.stack
  });
};

module.exports = {
  notFound,
  errorHandler
};
