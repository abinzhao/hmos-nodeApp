/**
 * 认证中间件
 */
const jwt = require('jsonwebtoken');
const { jwt: jwtConfig } = require('../config/config');
const logger = require('../utils/logger');

/**
 * 验证JWT令牌
 * @param {Request} req - Express请求对象
 * @param {Response} res - Express响应对象
 * @param {NextFunction} next - Express下一个中间件函数
 */
const authenticate = (req, res, next) => {
  // 从请求头获取token
  const token = req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    logger.warn('认证失败: 未提供令牌');
    return res.status(401).json({
      success: false,
      message: '认证失败: 未提供访问令牌'
    });
  }
  
  try {
    // 验证token
    const decoded = jwt.verify(token, jwtConfig.secret);
    
    // 将用户信息添加到请求对象
    req.user = decoded;
    next();
  } catch (error) {
    logger.warn(`认证失败: ${error.message}`);
    return res.status(401).json({
      success: false,
      message: '认证失败: 令牌无效或已过期'
    });
  }
};

/**
 * 验证用户是否为管理员
 * @param {Request} req - Express请求对象
 * @param {Response} res - Express响应对象
 * @param {NextFunction} next - Express下一个中间件函数
 */
const isAdmin = (req, res, next) => {
  if (!req.user || !req.user.isAdmin) {
    logger.warn(`用户 ${req.user?.id || 'unknown'} 尝试访问管理员资源`);
    return res.status(403).json({
      success: false,
      message: '权限不足: 需要管理员权限'
    });
  }
  
  next();
};

module.exports = {
  authenticate,
  isAdmin
};
