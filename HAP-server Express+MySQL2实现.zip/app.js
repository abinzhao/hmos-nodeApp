/**
 * 主应用文件
 */
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');
const { createConnectionPool } = require('./utils/dbSetup');
const logger = require('./utils/logger');

// 导入服务
const UserService = require('./service/user');
const ContentService = require('./service/content');
const SoftwareService = require('./service/software');
const CommentService = require('./service/comment');
const NotificationService = require('./service/notification');

// 导入中间件
const { notFound, errorHandler } = require('./middlewares/errorHandler');

/**
 * 初始化Express应用
 * @returns {Promise<express.Application>} Express应用实例
 */
const initApp = async () => {
  // 创建Express应用
  const app = express();

  // 基本中间件
  app.use(helmet()); // 安全头
  app.use(cors()); // 跨域支持
  app.use(express.json()); // JSON解析
  app.use(express.urlencoded({ extended: false })); // URL编码解析
  app.use(morgan('combined', { stream: logger.stream })); // HTTP请求日志

  // 创建数据库连接池
  const pool = await createConnectionPool();

  // 初始化服务
  const services = {
    pool,
    userService: new UserService(pool),
    contentService: new ContentService(pool),
    softwareService: new SoftwareService(pool),
    commentService: new CommentService(pool),
    notificationService: new NotificationService(pool)
  };

  // 确保上传目录存在
  const appDir = path.join(process.cwd(), 'FileData/HAP-app');
  const imageDir = path.join(process.cwd(), 'FileData/HAP-image');

  if (!fs.existsSync(appDir)) {
    fs.mkdirSync(appDir, { recursive: true });
  }

  if (!fs.existsSync(imageDir)) {
    fs.mkdirSync(imageDir, { recursive: true });
  }

  // 静态文件服务
  app.use(express.static(path.join(__dirname, 'public')));
  app.use('/FileData', express.static(path.join(__dirname, 'FileData')));

  // 路由
  app.use('/api/users', require('./routes/user')(services));
  app.use('/api/files', require('./routes/file')(services));
  app.use('/api/contents', require('./routes/content')(services));
  app.use('/api/softwares', require('./routes/software')(services));
  app.use('/api/comments', require('./routes/comment')(services));
  app.use('/api/notifications', require('./routes/notification')(services));

  // 根路由 - API状态
  app.get('/api', (req, res) => {
    res.json({
      success: true,
      message: 'HAP-Server API 正在运行',
      version: '1.0.0'
    });
  });

  // 根路由 - 前端入口
  app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });

  // 错误处理中间件
  app.use(notFound);
  app.use(errorHandler);

  return app;
};

module.exports = initApp;
