/**
 * 日志工具模块
 */
const winston = require('winston');
const path = require('path');
const fs = require('fs');

// 确保日志目录存在
const logDir = 'logs';
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

const { format, transports } = winston;
const { combine, timestamp, printf, colorize, align } = format;

// 自定义日志格式
const logFormat = printf(({ level, message, timestamp }) => {
  return `[${timestamp}] ${level}: ${message}`;
});

// 创建日志实例
const logger = winston.createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: combine(
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    align(),
    logFormat
  ),
  transports: [
    // 控制台输出
    new transports.Console({
      format: combine(colorize(), logFormat)
    }),
    // 文件输出
    new transports.File({ 
      filename: path.join(logDir, 'error.log'), 
      level: 'error' 
    }),
    new transports.File({ 
      filename: path.join(logDir, 'combined.log') 
    })
  ]
});

// 为Express请求添加一个简单的日志格式
logger.stream = {
  write: (message) => {
    logger.info(message.trim());
  }
};

module.exports = logger;
