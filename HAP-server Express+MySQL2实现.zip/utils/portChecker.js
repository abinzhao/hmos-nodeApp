/**
 * 端口检查工具
 */
const net = require('net');
const { exec } = require('child_process');
const logger = require('./logger');

/**
 * 检查端口是否被占用
 * @param {number} port - 要检查的端口
 * @returns {Promise<boolean>} - 端口是否可用
 */
const isPortAvailable = (port) => {
  return new Promise((resolve) => {
    const server = net.createServer();
    
    server.once('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        logger.warn(`端口 ${port} 已被占用`);
        resolve(false);
      }
    });
    
    server.once('listening', () => {
      server.close();
      resolve(true);
    });
    
    server.listen(port);
  });
};

/**
 * 查找占用端口的进程
 * @param {number} port - 端口号
 * @returns {Promise<number|null>} - 进程PID或null
 */
const findProcessUsingPort = (port) => {
  return new Promise((resolve) => {
    // 根据操作系统类型执行不同的命令
    const cmd = process.platform === 'win32' 
      ? `netstat -ano | findstr :${port}` 
      : `lsof -i :${port} -t`;
    
    exec(cmd, (error, stdout) => {
      if (error || !stdout) {
        return resolve(null);
      }

      let pid = null;
      if (process.platform === 'win32') {
        // Windows下解析PID
        const lines = stdout.split('\n');
        for (const line of lines) {
          if (line.includes(`LISTENING`)) {
            const parts = line.trim().split(/\s+/);
            pid = parts[parts.length - 1];
            break;
          }
        }
      } else {
        // Unix/Linux下直接获取PID
        pid = stdout.trim();
      }

      if (pid) {
        logger.info(`找到占用端口 ${port} 的进程: PID ${pid}`);
        resolve(parseInt(pid));
      } else {
        resolve(null);
      }
    });
  });
};

/**
 * 终止指定PID的进程
 * @param {number} pid - 进程ID
 * @returns {Promise<boolean>} - 是否成功终止
 */
const killProcess = (pid) => {
  return new Promise((resolve) => {
    if (!pid) {
      return resolve(false);
    }
    
    const cmd = process.platform === 'win32' 
      ? `taskkill /F /PID ${pid}` 
      : `kill -9 ${pid}`;
    
    exec(cmd, (error) => {
      if (error) {
        logger.error(`无法终止进程 ${pid}: ${error.message}`);
        return resolve(false);
      }
      
      logger.info(`成功终止进程 PID ${pid}`);
      resolve(true);
    });
  });
};

/**
 * 确保端口可用，如果被占用则尝试释放
 * @param {number} port - 要确保可用的端口
 * @returns {Promise<boolean>} - 端口是否可用
 */
const ensurePortAvailable = async (port) => {
  const isAvailable = await isPortAvailable(port);
  
  if (isAvailable) {
    return true;
  }
  
  // 尝试找到并终止占用端口的进程
  const pid = await findProcessUsingPort(port);
  if (pid) {
    const killed = await killProcess(pid);
    if (killed) {
      // 再次检查端口是否可用
      return await isPortAvailable(port);
    }
  }
  
  return false;
};

module.exports = {
  isPortAvailable,
  findProcessUsingPort,
  killProcess,
  ensurePortAvailable
};
