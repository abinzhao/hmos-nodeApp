/**
 * 数据库初始化工具
 */
const mysql = require('mysql2/promise');
const dbConfig = require('../config/database');
const logger = require('./logger');

// 数据表定义
const tables = {
  // 用户表
  users: `
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(50) NOT NULL UNIQUE,
      openid VARCHAR(100),
      gender ENUM('male', 'female', 'other') DEFAULT 'other',
      bio TEXT,
      tags VARCHAR(255),
      password VARCHAR(255) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      phone VARCHAR(20),
      email VARCHAR(100),
      is_admin BOOLEAN DEFAULT FALSE,
      INDEX idx_username (username),
      INDEX idx_openid (openid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,
  
  // 内容表（帖子/代码片段）
  contents: `
    CREATE TABLE IF NOT EXISTS contents (
      id INT AUTO_INCREMENT PRIMARY KEY,
      type ENUM('post', 'code') NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      content LONGTEXT,
      tags VARCHAR(255),
      user_id INT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      category VARCHAR(100),
      INDEX idx_type (type),
      INDEX idx_user_id (user_id),
      INDEX idx_category (category),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,
  
  // 软件表
  softwares: `
    CREATE TABLE IF NOT EXISTS softwares (
      id INT AUTO_INCREMENT PRIMARY KEY,
      package_name VARCHAR(255) NOT NULL,
      version VARCHAR(50) NOT NULL,
      name VARCHAR(100) NOT NULL,
      icon VARCHAR(255),
      description TEXT,
      update_info TEXT,
      screenshot1 VARCHAR(255),
      screenshot2 VARCHAR(255),
      screenshot3 VARCHAR(255),
      screenshot4 VARCHAR(255),
      user_id INT NOT NULL,
      upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      download_count INT DEFAULT 0,
      category VARCHAR(100),
      tags VARCHAR(255),
      INDEX idx_package_name (package_name),
      INDEX idx_user_id (user_id),
      INDEX idx_category (category),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,
  
  // 留言表
  comments: `
    CREATE TABLE IF NOT EXISTS comments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      content_id INT,
      software_id INT,
      user_id INT NOT NULL,
      content TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_content_id (content_id),
      INDEX idx_software_id (software_id),
      INDEX idx_user_id (user_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (content_id) REFERENCES contents(id) ON DELETE CASCADE,
      FOREIGN KEY (software_id) REFERENCES softwares(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `,
  
  // 系统通知表
  notifications: `
    CREATE TABLE IF NOT EXISTS notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      content TEXT NOT NULL,
      level ENUM('low', 'medium', 'high') DEFAULT 'medium',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      user_id INT,
      INDEX idx_level (level),
      INDEX idx_user_id (user_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `
};

/**
 * 初始化数据库连接
 * @returns {Promise<mysql.Connection>} MySQL连接对象
 */
const initDatabaseConnection = async () => {
  try {
    // 创建不指定数据库的连接
    const connection = await mysql.createConnection({
      host: dbConfig.host,
      user: dbConfig.user,
      password: dbConfig.password
    });
    
    logger.info('MySQL连接成功');
    return connection;
  } catch (error) {
    logger.error(`MySQL连接失败: ${error.message}`);
    throw error;
  }
};

/**
 * 创建数据库
 * @param {mysql.Connection} connection - MySQL连接
 * @returns {Promise<void>}
 */
const createDatabase = async (connection) => {
  try {
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` 
                           CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    logger.info(`数据库 '${dbConfig.database}' 创建成功或已存在`);
  } catch (error) {
    logger.error(`创建数据库失败: ${error.message}`);
    throw error;
  }
};

/**
 * 创建数据表
 * @param {mysql.Connection} connection - MySQL连接
 * @returns {Promise<void>}
 */
const createTables = async (connection) => {
  try {
    // 选择数据库
    await connection.query(`USE \`${dbConfig.database}\``);
    logger.info(`已选择数据库: ${dbConfig.database}`);
    
    // 创建所有表
    for (const [tableName, query] of Object.entries(tables)) {
      await connection.query(query);
      logger.info(`表 '${tableName}' 创建成功或已存在`);
    }
  } catch (error) {
    logger.error(`创建表失败: ${error.message}`);
    throw error;
  }
};

/**
 * 初始化数据库
 * @returns {Promise<void>}
 */
const initializeDatabase = async () => {
  let connection;
  
  try {
    // 初始化连接
    connection = await initDatabaseConnection();
    
    // 创建数据库
    await createDatabase(connection);
    
    // 创建表
    await createTables(connection);
    
    logger.info('数据库初始化完成');
  } catch (error) {
    logger.error(`数据库初始化失败: ${error.stack}`);
    throw error;
  } finally {
    if (connection) {
      await connection.end();
      logger.debug('数据库连接已关闭');
    }
  }
};

/**
 * 创建数据库连接池
 * @returns {Promise<mysql.Pool>} MySQL连接池
 */
const createConnectionPool = async () => {
  try {
    const pool = mysql.createPool(dbConfig);
    
    // 测试连接池
    const connection = await pool.getConnection();
    connection.release();
    
    logger.info('数据库连接池创建成功');
    return pool;
  } catch (error) {
    logger.error(`创建数据库连接池失败: ${error.message}`);
    throw error;
  }
};

module.exports = {
  initializeDatabase,
  createConnectionPool
};
