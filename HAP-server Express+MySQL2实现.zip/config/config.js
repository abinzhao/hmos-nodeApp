/**
 * 应用配置文件
 */
require('dotenv').config();

module.exports = {
  // 服务器配置
  server: {
    port: process.env.PORT || 3000,
    env: process.env.NODE_ENV || 'development',
  },
  
  // JWT配置
  jwt: {
    secret: process.env.JWT_SECRET || 'your_jwt_secret_key',
    expiresIn: process.env.JWT_EXPIRE || '24h',
  },
  
  // 文件上传配置
  upload: {
    appPath: process.env.UPLOAD_APP_PATH || 'FileData/HAP-app',
    imagePath: process.env.UPLOAD_IMAGE_PATH || 'FileData/HAP-image',
    fileSize: 50 * 1024 * 1024, // 50MB 文件大小限制
    allowedImageTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  },

  // TCP服务器配置
  tcpServer: {
    enabled: process.env.TCP_SERVER_ENABLED === 'true' || true,
    port: parseInt(process.env.TCP_SERVER_PORT) || 8888,
    allowedCommands: ['adb', 'hdc']
  }
};
