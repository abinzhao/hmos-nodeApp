/**
 * 系统通知路由模块
 */
const express = require('express');
const { body, validationResult } = require('express-validator');
const { authenticate, isAdmin } = require('../middlewares/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化系统通知路由
 * @param {Object} services - 服务对象集合
 * @returns {express.Router} 系统通知路由
 */
module.exports = (services) => {
  const { notificationService } = services;

  /**
   * @route   POST /api/notifications
   * @desc    创建新通知
   * @access  Private (Admin)
   */
  router.post(
    '/',
    [
      authenticate,
      // isAdmin, // 如果需要管理员权限可以取消注释
      body('title', '通知标题不能为空').notEmpty(),
      body('content', '通知内容不能为空').notEmpty(),
      body('level', '通知级别必须为 low、medium 或 high').optional().isIn(['low', 'medium', 'high'])
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const notificationData = req.body;
        const notification = await notificationService.createNotification(notificationData);

        res.status(201).json({
          success: true,
          data: notification
        });
      } catch (error) {
        logger.error(`创建通知失败: ${error.message}`);
        res.status(500).json({
          success: false,
          message: '服务器错误，无法创建通知'
        });
      }
    }
  );

  /**
   * @route   GET /api/notifications
   * @desc    获取所有通知
   * @access  Public
   */
  router.get('/', async (req, res) => {
    try {
      const notifications = await notificationService.getAllNotifications();

      res.json({
        success: true,
        data: notifications
      });
    } catch (error) {
      logger.error(`获取通知列表失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取通知列表'
      });
    }
  });

  /**
   * @route   GET /api/notifications/:id
   * @desc    获取单个通知
   * @access  Public
   */
  router.get('/:id', async (req, res) => {
    try {
      const notification = await notificationService.getNotificationById(req.params.id);

      res.json({
        success: true,
        data: notification
      });
    } catch (error) {
      logger.error(`获取通知失败: ${error.message}`);
      
      if (error.message.includes('通知不存在')) {
        return res.status(404).json({
          success: false,
          message: '通知不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取通知'
      });
    }
  });

  /**
   * @route   GET /api/notifications/user/:userId
   * @desc    获取用户的通知 (包括全局通知)
   * @access  Private
   */
  router.get('/user/:userId', authenticate, async (req, res) => {
    // 检查权限
    if (req.user.id != req.params.userId) {
      return res.status(403).json({
        success: false,
        message: '无权访问其他用户的通知'
      });
    }

    try {
      const notifications = await notificationService.getUserNotifications(req.params.userId);

      res.json({
        success: true,
        data: notifications
      });
    } catch (error) {
      logger.error(`获取用户通知失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取用户通知'
      });
    }
  });

  /**
   * @route   PUT /api/notifications/:id
   * @desc    更新通知
   * @access  Private (Admin)
   */
  router.put(
    '/:id',
    [
      authenticate,
      // isAdmin, // 如果需要管理员权限可以取消注释
      body('title', '通知标题不能为空').optional().notEmpty(),
      body('content', '通知内容不能为空').optional().notEmpty(),
      body('level', '通知级别必须为 low、medium 或 high').optional().isIn(['low', 'medium', 'high'])
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const notificationData = req.body;
        const notification = await notificationService.updateNotification(req.params.id, notificationData);

        res.json({
          success: true,
          data: notification
        });
      } catch (error) {
        logger.error(`更新通知失败: ${error.message}`);
        
        if (error.message.includes('通知不存在')) {
          return res.status(404).json({ false,
            message: '通知不存在'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法更新通知'
        });
      }
    }
  );

  /**
   * @route   DELETE /api/notifications/:id
   * @desc    删除通知
   * @access  Private (Admin)
   */
  router.delete('/:id', authenticate, /* isAdmin, */ async (req, res) => {
    try {
      await notificationService.deleteNotification(req.params.id);

      res.json({
        success: true,
        message: '通知已成功删除'
      });
    } catch (error) {
      logger.error(`删除通知失败: ${error.message}`);
      
      if (error.message.includes('通知不存在')) {
        return res.status(404).json({
          success: false,
          message: '通知不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法删除通知'
      });
    }
  });

  /**
   * @route   GET /api/notifications/level/:level
   * @desc    按级别获取通知
   * @access  Public
   */
  router.get('/level/:level', async (req, res) => {
    // 验证级别
    const level = req.params.level;
    if (!['low', 'medium', 'high'].includes(level)) {
      return res.status(400).json({
        success: false,
        message: '通知级别必须为 low、medium 或 high'
      });
    }

    try {
      const notifications = await notificationService.getNotificationsByLevel(level);

      res.json({
        success: true,
        data: notifications
      });
    } catch (error) {
      logger.error(`获取级别通知失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取级别通知'
      });
    }
  });

  return router;
};
