/**
 * 内容路由模块
 */
const express = require('express');
const { body, validationResult } = require('express-validator');
const { authenticate } = require('../middlewares/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化内容路由
 * @param {Object} services - 服务对象集合
 * @returns {express.Router} 内容路由
 */
module.exports = (services) => {
  const { contentService } = services;

  /**
   * @route   POST /api/contents
   * @desc    创建新内容
   * @access  Private
   */
  router.post(
    '/',
    [
      authenticate,
      body('type', '内容类型必须为 post 或 code').isIn(['post', 'code']),
      body('title', '标题不能为空').notEmpty(),
      body('content', '内容不能为空').notEmpty()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const contentData = {
          ...req.body,
          user_id: req.user.id
        };

        const content = await contentService.createContent(contentData);

        res.status(201).json({
          success: true,
          data: content
        });
      } catch (error) {
        logger.error(`创建内容失败: ${error.message}`);
        res.status(500).json({
          success: false,
          message: '服务器错误，无法创建内容'
        });
      }
    }
  );

  /**
   * @route   GET /api/contents
   * @desc    获取所有内容
   * @access  Public
   */
  router.get('/', async (req, res) => {
    try {
      // 可以通过查询参数过滤类型
      const { type } = req.query;
      const contents = await contentService.getAllContents(type);

      res.json({
        success: true,
        data: contents
      });
    } catch (error) {
      logger.error(`获取内容列表失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取内容列表'
      });
    }
  });

  /**
   * @route   GET /api/contents/:id
   * @desc    获取单个内容
   * @access  Public
   */
  router.get('/:id', async (req, res) => {
    try {
      const content = await contentService.getContentById(req.params.id);

      res.json({
        success: true,
        data: content
      });
    } catch (error) {
      logger.error(`获取内容失败: ${error.message}`);
      
      if (error.message.includes('内容不存在')) {
        return res.status(404).json({
          success: false,
          message: '内容不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取内容'
      });
    }
  });

  /**
   * @route   GET /api/contents/user/:userId
   * @desc    获取用户的内容
   * @access  Public
   */
  router.get('/user/:userId', async (req, res) => {
    try {
      const { type } = req.query;
      const contents = await contentService.getUserContents(req.params.userId, type);

      res.json({
        success: true,
        data: contents
      });
    } catch (error) {
      logger.error(`获取用户内容失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取用户内容'
      });
    }
  });

  /**
   * @route   PUT /api/contents/:id
   * @desc    更新内容
   * @access  Private
   */
  router.put(
    '/:id',
    [
      authenticate,
      body('title', '标题不能为空').optional().notEmpty(),
      body('content', '内容不能为空').optional().notEmpty()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        // 检查内容是否属于当前用户
        const existingContent = await contentService.getContentById(req.params.id);
        
        if (existingContent.user_id !== req.user.id) {
          return res.status(403).json({
            success: false,
            message: '无权修改其他用户的内容'
          });
        }

        const contentData = req.body;
        const content = await contentService.updateContent(req.params.id, contentData);

        res.json({
          success: true,
          data: content
        });
      } catch (error) {
        logger.error(`更新内容失败: ${error.message}`);
        
        if (error.message.includes('内容不存在')) {
          return res.status(404).json({
            success: false,
            message: '内容不存在'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法更新内容'
        });
      }
    }
  );

  /**
   * @route   DELETE /api/contents/:id
   * @desc    删除内容
   * @access  Private
   */
  router.delete('/:id', authenticate, async (req, res) => {
    try {
      // 检查内容是否属于当前用户
      const existingContent = await contentService.getContentById(req.params.id);
      
      if (existingContent.user_id !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: '无权删除其他用户的内容'
        });
      }

      await contentService.deleteContent(req.params.id);

      res.json({
        success: true,
        message: '内容已成功删除'
      });
    } catch (error) {
      logger.error(`删除内容失败: ${error.message}`);
      
      if (error.message.includes('内容不存在')) {
        return res.status(404).json({
          success: false,
          message: '内容不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法删除内容'
      });
    }
  });

  /**
   * @route   GET /api/contents/category/:category
   * @desc    按类别获取内容
   * @access  Public
   */
  router.get('/category/:category', async (req, res) => {
    try {
      const { type } = req.query;
      const contents = await contentService.getContentsByCategory(req.params.category, type);

      res.json({
        success: true,
        data: contents
      });
    } catch (error) {
      logger.error(`获取类别内容失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取类别内容'
      });
    }
  });

  return router;
};
