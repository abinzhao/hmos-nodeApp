/**
 * 用户路由模块
 */
const express = require('express');
const { body, validationResult } = require('express-validator');
const { authenticate } = require('../middlewares/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化用户路由
 * @param {Object} services - 服务对象集合
 * @returns {express.Router} 用户路由
 */
module.exports = (services) => {
  const { userService } = services;

  /**
   * @route   POST /api/users/register
   * @desc    注册新用户
   * @access  Public
   */
  router.post(
    '/register',
    [
      body('username', '用户名必须在3-50个字符之间').isLength({ min: 3, max: 50 }),
      body('password', '密码必须至少6个字符').isLength({ min: 6 }),
      body('email', '请提供有效的电子邮件').optional().isEmail()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const userData = req.body;
        const user = await userService.createUser(userData);

        res.status(201).json({
          success: true,
          data: user
        });
      } catch (error) {
        logger.error(`注册用户失败: ${error.message}`);
        
        if (error.message.includes('用户名已存在')) {
          return res.status(400).json({
            success: false,
            message: '用户名已被使用'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法注册用户'
        });
      }
    }
  );

  /**
   * @route   POST /api/users/login
   * @desc    用户登录
   * @access  Public
   */
  router.post(
    '/login',
    [
      body('username', '请输入用户名').exists(),
      body('password', '请输入密码').exists()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const { username, password } = req.body;
        const result = await userService.loginUser(username, password);

        res.json({
          success: true,
          data: result
        });
      } catch (error) {
        logger.error(`用户登录失败: ${error.message}`);
        
        if (error.message.includes('用户不存在') || error.message.includes('密码错误')) {
          return res.status(401).json({
            success: false,
            message: '用户名或密码不正确'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法登录'
        });
      }
    }
  );

  /**
   * @route   GET /api/users
   * @desc    获取所有用户
   * @access  Private
   */
  router.get('/', authenticate, async (req, res) => {
    try {
      const users = await userService.getAllUsers();

      res.json({
        success: true,
        data: users
      });
    } catch (error) {
      logger.error(`获取所有用户失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取用户列表'
      });
    }
  });

  /**
   * @route   GET /api/users/:id
   * @desc    获取单个用户
   * @access  Private
   */
  router.get('/:id', authenticate, async (req, res) => {
    try {
      const user = await userService.getUserById(req.params.id);

      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      logger.error(`获取用户失败: ${error.message}`);
      
      if (error.message.includes('用户不存在')) {
        return res.status(404).json({
          success: false,
          message: '用户不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取用户信息'
      });
    }
  });

  /**
   * @route   GET /api/users/profile/me
   * @desc    获取当前用户信息
   * @access  Private
   */
  router.get('/profile/me', authenticate, async (req, res) => {
    try {
      const user = await userService.getUserById(req.user.id);

      res.json({
        success: true,
        data: user
      });
    } catch (error) {
      logger.error(`获取当前用户信息失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取当前用户信息'
      });
    }
  });

  /**
   * @route   PUT /api/users/:id
   * @desc    更新用户信息
   * @access  Private
   */
  router.put(
    '/:id',
    [
      authenticate,
      body('username', '用户名必须在3-50个字符之间').optional().isLength({ min: 3, max: 50 }),
      body('email', '请提供有效的电子邮件').optional().isEmail(),
      body('password', '密码必须至少6个字符').optional().isLength({ min: 6 })
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      // 检查权限
      if (req.user.id != req.params.id) {
        return res.status(403).json({
          success: false,
          message: '无权修改其他用户信息'
        });
      }

      try {
        const userData = req.body;
        const user = await userService.updateUser(req.params.id, userData);

        res.json({
          success: true,
          data: user
        });
      } catch (error) {
        logger.error(`更新用户失败: ${error.message}`);
        
        if (error.message.includes('用户不存在')) {
          return res.status(404).json({
            success: false,
            message: '用户不存在'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法更新用户信息'
        });
      }
    }
  );

  /**
   * @route   DELETE /api/users/:id
   * @desc    删除用户
   * @access  Private
   */
  router.delete('/:id', authenticate, async (req, res) => {
    // 检查权限
    if (req.user.id != req.params.id) {
      return res.status(403).json({
        success: false,
        message: '无权删除其他用户'
      });
    }

    try {
      await userService.deleteUser(req.params.id);

      res.json({
        success: true,
        message: '用户已成功删除'
      });
    } catch (error) {
      logger.error(`删除用户失败: ${error.message}`);
      
      if (error.message.includes('用户不存在')) {
        return res.status(404).json({
          success: false,
          message: '用户不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法删除用户'
      });
    }
  });

  return router;
};
