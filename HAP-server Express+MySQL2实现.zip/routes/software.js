/**
 * 软件路由模块
 */
const express = require('express');
const { body, validationResult } = require('express-validator');
const { authenticate } = require('../middlewares/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化软件路由
 * @param {Object} services - 服务对象集合
 * @returns {express.Router} 软件路由
 */
module.exports = (services) => {
  const { softwareService } = services;

  /**
   * @route   POST /api/softwares
   * @desc    创建新软件
   * @access  Private
   */
  router.post(
    '/',
    [
      authenticate,
      body('package_name', '包名不能为空').notEmpty(),
      body('version', '版本不能为空').notEmpty(),
      body('name', '软件名称不能为空').notEmpty(),
      body('screenshot1', '至少需要一张软件截图').optional(),
      body('screenshot2', '软件截图URL').optional(),
      body('screenshot3', '软件截图URL').optional(),
      body('screenshot4', '软件截图URL').optional()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const softwareData = {
          ...req.body,
          user_id: req.user.id
        };

        const software = await softwareService.createSoftware(softwareData);

        res.status(201).json({
          success: true,
          data: software
        });
      } catch (error) {
        logger.error(`创建软件失败: ${error.message}`);
        res.status(500).json({
          success: false,
          message: '服务器错误，无法创建软件'
        });
      }
    }
  );

  /**
   * @route   GET /api/softwares
   * @desc    获取所有软件
   * @access  Public
   */
  router.get('/', async (req, res) => {
    try {
      const softwares = await softwareService.getAllSoftwares();

      res.json({
        success: true,
        data: softwares
      });
    } catch (error) {
      logger.error(`获取软件列表失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取软件列表'
      });
    }
  });

  /**
   * @route   GET /api/softwares/:id
   * @desc    获取单个软件
   * @access  Public
   */
  router.get('/:id', async (req, res) => {
    try {
      const software = await softwareService.getSoftwareById(req.params.id);

      res.json({
        success: true,
        data: software
      });
    } catch (error) {
      logger.error(`获取软件失败: ${error.message}`);
      
      if (error.message.includes('软件不存在')) {
        return res.status(404).json({
          success: false,
          message: '软件不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取软件'
      });
    }
  });

  /**
   * @route   GET /api/softwares/user/:userId
   * @desc    获取用户的软件
   * @access  Public
   */
  router.get('/user/:userId', async (req, res) => {
    try {
      const softwares = await softwareService.getUserSoftwares(req.params.userId);

      res.json({
        success: true,
        data: softwares
      });
    } catch (error) {
      logger.error(`获取用户软件失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取用户软件'
      });
    }
  });

  /**
   * @route   PUT /api/softwares/:id
   * @desc    更新软件
   * @access  Private
   */
  router.put(
    '/:id',
    [
      authenticate,
      body('name', '软件名称不能为空').optional().notEmpty(),
      body('version', '版本不能为空').optional().notEmpty()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        // 检查软件是否属于当前用户
        const existingSoftware = await softwareService.getSoftwareById(req.params.id);
        
        if (existingSoftware.user_id !== req.user.id) {
          return res.status(403).json({
            success: false,
            message: '无权修改其他用户的软件'
          });
        }

        const softwareData = req.body;
        const software = await softwareService.updateSoftware(req.params.id, softwareData);

        res.json({
          success: true,
          data: software
        });
      } catch (error) {
        logger.error(`更新软件失败: ${error.message}`);
        
        if (error.message.includes('软件不存在')) {
          return res.status(404).json({
            success: false,
            message: '软件不存在'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法更新软件'
        });
      }
    }
  );

  /**
   * @route   DELETE /api/softwares/:id
   * @desc    删除软件
   * @access  Private
   */
  router.delete('/:id', authenticate, async (req, res) => {
    try {
      // 检查软件是否属于当前用户
      const existingSoftware = await softwareService.getSoftwareById(req.params.id);
      
      if (existingSoftware.user_id !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: '无权删除其他用户的软件'
        });
      }

      await softwareService.deleteSoftware(req.params.id);

      res.json({
        success: true,
        message: '软件已成功删除'
      });
    } catch (error) {
      logger.error(`删除软件失败: ${error.message}`);
      
      if (error.message.includes('软件不存在')) {
        return res.status(404).json({
          success: false,
          message: '软件不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法删除软件'
      });
    }
  });

  /**
   * @route   POST /api/softwares/:id/download
   * @desc    增加软件下载次数
   * @access  Public
   */
  router.post('/:id/download', async (req, res) => {
    try {
      const newCount = await softwareService.incrementDownload(req.params.id);

      res.json({
        success: true,
        data: {
          download_count: newCount
        }
      });
    } catch (error) {
      logger.error(`更新下载次数失败: ${error.message}`);
      
      if (error.message.includes('软件不存在')) {
        return res.status(404).json({
          success: false,
          message: '软件不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法更新下载次数'
      });
    }
  });

  /**
   * @route   GET /api/softwares/category/:category
   * @desc    按类别获取软件
   * @access  Public
   */
  router.get('/category/:category', async (req, res) => {
    try {
      const softwares = await softwareService.getSoftwaresByCategory(req.params.category);

      res.json({
        success: true,
        data: softwares
      });
    } catch (error) {
      logger.error(`获取类别软件失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取类别软件'
      });
    }
  });

  return router;
};
