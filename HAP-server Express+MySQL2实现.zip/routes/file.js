/**
 * 文件上传路由模块
 */
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { authenticate } = require('../middlewares/auth');
const config = require('../config/config');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化文件上传路由
 * @returns {express.Router} 文件上传路由
 */
module.exports = () => {
  // 确保上传目录存在
  const appDir = path.join(process.cwd(), config.upload.appPath);
  const imageDir = path.join(process.cwd(), config.upload.imagePath);

  if (!fs.existsSync(appDir)) {
    fs.mkdirSync(appDir, { recursive: true });
  }

  if (!fs.existsSync(imageDir)) {
    fs.mkdirSync(imageDir, { recursive: true });
  }

  // 配置存储
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      // 根据文件类型决定存储目录
      if (file.originalname.endsWith('.hap')) {
        cb(null, appDir);
      } else {
        cb(null, imageDir);
      }
    },
    filename: (req, file, cb) => {
      // 生成唯一文件名
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const ext = path.extname(file.originalname);
      cb(null, file.fieldname + '-' + uniqueSuffix + ext);
    }
  });

  // 文件过滤器
  const fileFilter = (req, file, cb) => {
    // 允许 .hap 文件和图片文件
    if (file.originalname.endsWith('.hap') || 
        config.upload.allowedImageTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('不支持的文件类型'), false);
    }
  };

  // 配置上传
  const upload = multer({
    storage,
    fileFilter,
    limits: {
      fileSize: config.upload.fileSize // 文件大小限制
    }
  });

  /**
   * @route   POST /api/files/upload
   * @desc    上传文件
   * @access  Private
   */
  router.post('/upload', authenticate, upload.single('file'), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: '没有文件被上传'
        });
      }

      // 生成文件URL
      const protocol = req.secure ? 'https' : 'http';
      const host = req.get('host');
      const relativePath = req.file.path.replace(process.cwd(), '');
      const fileUrl = `${protocol}://${host}${relativePath.replace(/\\/g, '/')}`;

      logger.info(`文件上传成功: ${req.file.originalname} -> ${req.file.path}`);

      res.status(201).json({
        success: true,
        data: {
          filename: req.file.filename,
          originalName: req.file.originalname,
          mimetype: req.file.mimetype,
          size: req.file.size,
          url: fileUrl
        }
      });
    } catch (error) {
      logger.error(`文件上传失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，文件上传失败'
      });
    }
  });

  /**
   * @route   POST /api/files/upload/multiple
   * @desc    上传多个文件
   * @access  Private
   */
  router.post('/upload/multiple', authenticate, upload.array('files', 10), (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({
          success: false,
          message: '没有文件被上传'
        });
      }

      const protocol = req.secure ? 'https' : 'http';
      const host = req.get('host');
      
      // 处理每个文件并创建结果数组
      const filesInfo = req.files.map(file => {
        const relativePath = file.path.replace(process.cwd(), '');
        const fileUrl = `${protocol}://${host}${relativePath.replace(/\\/g, '/')}`;
        
        return {
          filename: file.filename,
          originalName: file.originalname,
          mimetype: file.mimetype,
          size: file.size,
          url: fileUrl
        };
      });

      logger.info(`多文件上传成功: ${req.files.length}个文件`);

      res.status(201).json({
        success: true,
        data: filesInfo
      });
    } catch (error) {
      logger.error(`多文件上传失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，文件上传失败'
      });
    }
  });

  return router;
};
