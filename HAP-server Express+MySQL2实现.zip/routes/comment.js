/**
 * 留言路由模块
 */
const express = require('express');
const { body, validationResult } = require('express-validator');
const { authenticate } = require('../middlewares/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化留言路由
 * @param {Object} services - 服务对象集合
 * @returns {express.Router} 留言路由
 */
module.exports = (services) => {
  const { commentService } = services;

  /**
   * @route   POST /api/comments
   * @desc    创建新留言
   * @access  Private
   */
  router.post(
    '/',
    [
      authenticate,
      body('content', '留言内容不能为空').notEmpty(),
      body('content_id', '内容ID或软件ID必须提供一个').custom((value, { req }) => {
        return (value !== undefined && value !== null) || (req.body.software_id !== undefined && req.body.software_id !== null);
      })
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        const commentData = {
          ...req.body,
          user_id: req.user.id
        };

        const comment = await commentService.createComment(commentData);

        res.status(201).json({
          success: true,
          data: comment
        });
      } catch (error) {
        logger.error(`创建留言失败: ${error.message}`);
        res.status(500).json({
          success: false,
          message: '服务器错误，无法创建留言'
        });
      }
    }
  );

  /**
   * @route   GET /api/comments/content/:contentId
   * @desc    获取内容的留言
   * @access  Public
   */
  router.get('/content/:contentId', async (req, res) => {
    try {
      const comments = await commentService.getContentComments(req.params.contentId);

      res.json({
        success: true,
        data: comments
      });
    } catch (error) {
      logger.error(`获取内容留言失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取内容留言'
      });
    }
  });

  /**
   * @route   GET /api/comments/software/:softwareId
   * @desc    获取软件的留言
   * @access  Public
   */
  router.get('/software/:softwareId', async (req, res) => {
    try {
      const comments = await commentService.getSoftwareComments(req.params.softwareId);

      res.json({
        success: true,
        data: comments
      });
    } catch (error) {
      logger.error(`获取软件留言失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取软件留言'
      });
    }
  });

  /**
   * @route   GET /api/comments/user/:userId
   * @desc    获取用户的留言
   * @access  Public
   */
  router.get('/user/:userId', async (req, res) => {
    try {
      const comments = await commentService.getUserComments(req.params.userId);

      res.json({
        success: true,
        data: comments
      });
    } catch (error) {
      logger.error(`获取用户留言失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取用户留言'
      });
    }
  });

  /**
   * @route   PUT /api/comments/:id
   * @desc    更新留言
   * @access  Private
   */
  router.put(
    '/:id',
    [
      authenticate,
      body('content', '留言内容不能为空').notEmpty()
    ],
    async (req, res) => {
      // 验证请求
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          errors: errors.array()
        });
      }

      try {
        // 获取留言
        const [comments] = await services.pool.query(
          'SELECT * FROM comments WHERE id = ?',
          [req.params.id]
        );

        if (comments.length === 0) {
          return res.status(404).json({
            success: false,
            message: '留言不存在'
          });
        }

        // 检查留言是否属于当前用户
        if (comments[0].user_id !== req.user.id) {
          return res.status(403).json({
            success: false,
            message: '无权修改其他用户的留言'
          });
        }

        const comment = await commentService.updateComment(req.params.id, req.body.content);

        res.json({
          success: true,
          data: comment
        });
      } catch (error) {
        logger.error(`更新留言失败: ${error.message}`);
        
        if (error.message.includes('留言不存在')) {
          return res.status(404).json({
            success: false,
            message: '留言不存在'
          });
        }

        res.status(500).json({
          success: false,
          message: '服务器错误，无法更新留言'
        });
      }
    }
  );

  /**
   * @route   DELETE /api/comments/:id
   * @desc    删除留言
   * @access  Private
   */
  router.delete('/:id', authenticate, async (req, res) => {
    try {
      // 获取留言
      const [comments] = await services.pool.query(
        'SELECT * FROM comments WHERE id = ?',
        [req.params.id]
      );

      if (comments.length === 0) {
        return res.status(404).json({
          success: false,
          message: '留言不存在'
        });
      }

      // 检查留言是否属于当前用户
      if (comments[0].user_id !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: '无权删除其他用户的留言'
        });
      }

      await commentService.deleteComment(req.params.id);

      res.json({
        success: true,
        message: '留言已成功删除'
      });
    } catch (error) {
      logger.error(`删除留言失败: ${error.message}`);
      
      if (error.message.includes('留言不存在')) {
        return res.status(404).json({
          success: false,
          message: '留言不存在'
        });
      }

      res.status(500).json({
        success: false,
        message: '服务器错误，无法删除留言'
      });
    }
  });

  return router;
};
