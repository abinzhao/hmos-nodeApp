/**
 * TCP服务器管理路由模块
 */
const express = require('express');
const { authenticate, isAdmin } = require('../middlewares/auth');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * 初始化TCP服务器管理路由
 * @param {Object} services - 服务对象集合
 * @param {TcpServer} tcpServer - TCP服务器实例
 * @returns {express.Router} TCP服务器管理路由
 */
module.exports = (services, tcpServer) => {
  /**
   * @route   GET /api/tcp/status
   * @desc    获取TCP服务器状态
   * @access  Private (Admin)
   */
  router.get('/status', authenticate, isAdmin, (req, res) => {
    try {
      if (!tcpServer) {
        return res.json({
          success: true,
          data: {
            running: false,
            message: 'TCP服务器未启动'
          }
        });
      }

      res.json({
        success: true,
        data: {
          running: true,
          port: tcpServer.port,
          clientCount: tcpServer.getClientCount(),
          allowedCommands: tcpServer.allowedCommands
        }
      });
    } catch (error) {
      logger.error(`获取TCP服务器状态失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取TCP服务器状态'
      });
    }
  });

  /**
   * @route   GET /api/tcp/clients
   * @desc    获取TCP客户端列表
   * @access  Private (Admin)
   */
  router.get('/clients', authenticate, isAdmin, (req, res) => {
    try {
      if (!tcpServer) {
        return res.json({
          success: true,
          data: {
            clients: []
          }
        });
      }

      const clients = tcpServer.getClientList();

      res.json({
        success: true,
        data: {
          clientCount: clients.length,
          clients
        }
      });
    } catch (error) {
      logger.error(`获取TCP客户端列表失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取TCP客户端列表'
      });
    }
  });

  /**
   * @route   POST /api/tcp/broadcast
   * @desc    向所有TCP客户端广播消息
   * @access  Private (Admin)
   */
  router.post('/broadcast', authenticate, isAdmin, (req, res) => {
    try {
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({
          success: false,
          message: '消息内容不能为空'
        });
      }

      if (!tcpServer) {
        return res.status(400).json({
          success: false,
          message: 'TCP服务器未启动'
        });
      }

      tcpServer.broadcast(message);

      res.json({
        success: true,
        message: '消息广播成功'
      });
    } catch (error) {
      logger.error(`广播TCP消息失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法广播消息'
      });
    }
  });

  /**
   * @route   POST /api/tcp/client/:clientId/message
   * @desc    向指定客户端发送消息
   * @access  Private (Admin)
   */
  router.post('/client/:clientId/message', authenticate, isAdmin, (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({
          success: false,
          message: '消息内容不能为空'
        });
      }

      if (!tcpServer) {
        return res.status(400).json({
          success: false,
          message: 'TCP服务器未启动'
        });
      }

      const client = tcpServer.clients.get(clientId);
      if (!client) {
        return res.status(404).json({
          success: false,
          message: `客户端 ID ${clientId} 不存在或已断开连接`
        });
      }

      client.socket.write(`[管理员消息] ${message}\r\n> `);

      res.json({
        success: true,
        message: `消息已发送至客户端 ${clientId}`
      });
    } catch (error) {
      logger.error(`发送消息至客户端失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法发送消息'
      });
    }
  });

  /**
   * @route   POST /api/tcp/client/:clientId/disconnect
   * @desc    断开指定客户端连接
   * @access  Private (Admin)
   */
  router.post('/client/:clientId/disconnect', authenticate, isAdmin, (req, res) => {
    try {
      const clientId = parseInt(req.params.clientId);

      if (!tcpServer) {
        return res.status(400).json({
          success: false,
          message: 'TCP服务器未启动'
        });
      }

      const client = tcpServer.clients.get(clientId);
      if (!client) {
        return res.status(404).json({
          success: false,
          message: `客户端 ID ${clientId} 不存在或已断开连接`
        });
      }

      // 发送断开连接消息并关闭连接
      client.socket.write('管理员已断开您的连接\r\n');
      client.socket.end();
      client.socket.destroy();
      tcpServer.clients.delete(clientId);

      res.json({
        success: true,
        message: `客户端 ${clientId} 已断开连接`
      });
    } catch (error) {
      logger.error(`断开客户端连接失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法断开客户端连接'
      });
    }
  });

  /**
   * @route   POST /api/tcp/restart
   * @desc    重启TCP服务器
   * @access  Private (Admin)
   */
  router.post('/restart', authenticate, isAdmin, async (req, res) => {
    try {
      if (!tcpServer) {
        return res.status(400).json({
          success: false,
          message: 'TCP服务器未启动或不可用'
        });
      }

      // 停止当前TCP服务器
      await tcpServer.stop();
      
      // 重新启动TCP服务器
      await tcpServer.start();

      res.json({
        success: true,
        message: 'TCP服务器已成功重启',
        data: {
          port: tcpServer.port,
          clientCount: tcpServer.getClientCount()
        }
      });
    } catch (error) {
      logger.error(`重启TCP服务器失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法重启TCP服务器'
      });
    }
  });

  /**
   * @route   GET /api/tcp/commands
   * @desc    获取允许执行的命令前缀列表
   * @access  Private (Admin)
   */
  router.get('/commands', authenticate, isAdmin, (req, res) => {
    try {
      if (!tcpServer) {
        return res.status(400).json({
          success: false,
          message: 'TCP服务器未启动'
        });
      }

      res.json({
        success: true,
        data: {
          allowedCommands: tcpServer.allowedCommands
        }
      });
    } catch (error) {
      logger.error(`获取允许的命令前缀失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法获取允许的命令前缀'
      });
    }
  });

  /**
   * @route   POST /api/tcp/commands
   * @desc    更新允许执行的命令前缀列表
   * @access  Private (Admin)
   */
  router.post('/commands', authenticate, isAdmin, (req, res) => {
    try {
      const { commands } = req.body;

      if (!Array.isArray(commands) || commands.length === 0) {
        return res.status(400).json({
          success: false,
          message: '命令前缀列表必须是非空数组'
        });
      }

      if (!tcpServer) {
        return res.status(400).json({
          success: false,
          message: 'TCP服务器未启动'
        });
      }

      // 更新允许的命令前缀
      tcpServer.allowedCommands = commands;

      res.json({
        success: true,
        message: '允许的命令前缀已更新',
        data: {
          allowedCommands: tcpServer.allowedCommands
        }
      });
    } catch (error) {
      logger.error(`更新允许的命令前缀失败: ${error.message}`);
      res.status(500).json({
        success: false,
        message: '服务器错误，无法更新允许的命令前缀'
      });
    }
  });

  return router;
};
