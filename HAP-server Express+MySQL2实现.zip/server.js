/**
 * 服务器启动文件
 */
const http = require('http');
const { server: serverConfig, tcpServer: tcpConfig } = require('./config/config');
const { ensurePortAvailable } = require('./utils/portChecker');
const { initializeDatabase } = require('./utils/dbSetup');
const initApp = require('./app');
const logger = require('./utils/logger');
const TcpServer = require('./service/tcpServer');

// 全局TCP服务器实例
let tcpServer = null;

/**
 * 正常关闭服务器
 * @param {http.Server} server - HTTP服务器实例
 */
const gracefulShutdown = async (server) => {
  logger.info('接收到关闭信号，正在优雅地关闭服务器...');
  
  // 关闭TCP服务器
  if (tcpServer) {
    logger.info('正在关闭TCP服务器...');
    await tcpServer.stop();
  }
  
  // 关闭HTTP服务器
  server.close(() => {
    logger.info('HTTP服务器已关闭');
    process.exit(0);
  });

  // 如果10秒内无法正常关闭，则强制退出
  setTimeout(() => {
    logger.error('无法在规定时间内关闭服务器，强制退出');
    process.exit(1);
  }, 10000);
};

/**
 * 启动HTTP服务器
 * @param {express.Application} app - Express应用实例
 * @param {number} port - 服务器端口
 * @returns {Promise<http.Server>} HTTP服务器实例
 */
const startServer = (app, port) => {
  return new Promise((resolve) => {
    const server = http.createServer(app);

    server.listen(port, () => {
      logger.info(`🚀 服务器在端口 ${port} 上启动`);
      logger.info(`环境: ${process.env.NODE_ENV || 'development'}`);
      resolve(server);
    });

    // 处理服务器错误
    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        logger.error(`端口 ${port} 已被占用`);
      } else {
        logger.error(`服务器错误: ${error.message}`);
      }
    });

    // 设置关闭处理
    process.on('SIGTERM', () => gracefulShutdown(server));
    process.on('SIGINT', () => gracefulShutdown(server));
  });
};

/**
 * 启动TCP服务器
 */
const startTcpServer = async () => {
  if (!tcpConfig.enabled) {
    logger.info('TCP服务器已禁用，跳过启动');
    return;
  }

  try {
    // 检查TCP服务器端口是否可用
    logger.info(`检查TCP服务器端口 ${tcpConfig.port} 是否可用...`);
    const isTcpPortAvailable = await ensurePortAvailable(tcpConfig.port);
    
    if (!isTcpPortAvailable) {
      logger.error(`无法释放TCP服务器端口 ${tcpConfig.port}，TCP服务器将不会启动`);
      return;
    }

    // 创建并启动TCP服务器
    tcpServer = new TcpServer({
      port: tcpConfig.port,
      allowedCommands: tcpConfig.allowedCommands
    });
    
    await tcpServer.start();
    logger.info(`TCP服务器已启动，监听端口 ${tcpConfig.port}`);
  } catch (error) {
    logger.error(`启动TCP服务器失败: ${error.message}`);
  }
};

/**
 * 主函数 - 启动服务器
 */
const main = async () => {
  try {
    logger.info('正在启动 HAP-Server...');
    
    // 获取配置的端口
    const port = serverConfig.port;
    
    // 确保端口可用
    logger.info(`检查HTTP服务器端口 ${port} 是否可用...`);
    const isPortAvailable = await ensurePortAvailable(port);
    
    if (!isPortAvailable) {
      logger.error(`无法释放HTTP服务器端口 ${port}，请尝试其他端口或手动终止占用进程`);
      process.exit(1);
    }
    
    // 初始化数据库
    logger.info('正在初始化数据库...');
    await initializeDatabase();
    
    // 初始化应用
    logger.info('正在初始化应用...');
    const app = await initApp();
    
    // 启动HTTP服务器
    logger.info('正在启动HTTP服务器...');
    const server = await startServer(app, port);
    
    // 启动TCP服务器
    await startTcpServer();
    
    logger.info('HAP-Server 已成功启动并准备就绪');
    logger.info(`API文档: http://localhost:${port}/api`);
    logger.info(`前端页面: http://localhost:${port}`);
  } catch (error) {
    logger.error(`启动服务器失败: ${error.stack}`);
    process.exit(1);
  }
};

// 启动服务器
main();
